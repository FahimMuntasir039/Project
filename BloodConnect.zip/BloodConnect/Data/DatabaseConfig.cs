namespace BloodConnect.Data;

public static class DatabaseConfig
{
    // Update this connection string if your SQL Server instance is different.
    public const string ConnectionString =
        "Server=localhost\\SQLEXPRESS;Database=BloodConnectDb;Trusted_Connection=True;MultipleActiveResultSets=true;Encrypt=True;TrustServerCertificate=True";
}
