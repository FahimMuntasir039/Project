IF DB_ID('BloodConnectDb') IS NULL
BEGIN
    CREATE DATABASE BloodConnectDb;
END;
GO

USE BloodConnectDb;
GO

IF OBJECT_ID('Users', 'U') IS NULL
BEGIN
    CREATE TABLE Users (
        UserId INT IDENTITY(1,1) PRIMARY KEY,
        Name NVARCHAR(100) NOT NULL,
        Email NVARCHAR(120) NOT NULL UNIQUE,
        Password NVARCHAR(200) NOT NULL,
        Role NVARCHAR(20) NOT NULL CHECK (Role IN ('Donor', 'Receiver', 'Admin')),
        CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME()
    );
END;
GO

IF OBJECT_ID('Donors', 'U') IS NULL
BEGIN
    CREATE TABLE Donors (
        DonorId INT IDENTITY(1,1) PRIMARY KEY,
        UserId INT NOT NULL UNIQUE,
        BloodGroup NVARCHAR(5) NOT NULL,
        Age INT NOT NULL CHECK (Age >= 1 AND Age <= 120),
        Phone NVARCHAR(20) NOT NULL,
        Address NVARCHAR(200) NOT NULL,
        LastDonationDate DATE NULL,
        CONSTRAINT FK_Donors_Users FOREIGN KEY (UserId) REFERENCES Users(UserId) ON DELETE CASCADE
    );
END;
GO

IF OBJECT_ID('Receivers', 'U') IS NULL
BEGIN
    CREATE TABLE Receivers (
        ReceiverId INT IDENTITY(1,1) PRIMARY KEY,
        UserId INT NOT NULL UNIQUE,
        BloodGroupNeeded NVARCHAR(5) NOT NULL,
        Phone NVARCHAR(20) NOT NULL,
        Address NVARCHAR(200) NOT NULL,
        CONSTRAINT FK_Receivers_Users FOREIGN KEY (UserId) REFERENCES Users(UserId) ON DELETE CASCADE
    );
END;
GO

IF OBJECT_ID('BloodRequests', 'U') IS NULL
BEGIN
    CREATE TABLE BloodRequests (
        RequestId INT IDENTITY(1,1) PRIMARY KEY,
        ReceiverId INT NOT NULL,
        BloodGroup NVARCHAR(5) NOT NULL,
        Quantity INT NOT NULL CHECK (Quantity > 0),
        Status NVARCHAR(20) NOT NULL DEFAULT 'Pending' CHECK (Status IN ('Pending', 'Approved', 'Rejected')),
        RequestDate DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
        CONSTRAINT FK_BloodRequests_Receivers FOREIGN KEY (ReceiverId) REFERENCES Receivers(ReceiverId) ON DELETE CASCADE
    );
END;
GO

IF OBJECT_ID('BloodStock', 'U') IS NULL
BEGIN
    CREATE TABLE BloodStock (
        StockId INT IDENTITY(1,1) PRIMARY KEY,
        BloodGroup NVARCHAR(5) NOT NULL,
        Quantity INT NOT NULL CHECK (Quantity >= 0),
        HospitalName NVARCHAR(120) NOT NULL,
        CONSTRAINT UQ_BloodStock_Group_Hospital UNIQUE (BloodGroup, HospitalName)
    );
END;
GO

IF OBJECT_ID('DonationAppointments', 'U') IS NULL
BEGIN
    CREATE TABLE DonationAppointments (
        AppointmentId INT IDENTITY(1,1) PRIMARY KEY,
        DonorId INT NOT NULL,
        AppointmentDate DATETIME2 NOT NULL,
        Status NVARCHAR(20) NOT NULL DEFAULT 'Pending' CHECK (Status IN ('Pending', 'Approved', 'Rejected', 'Completed')),
        CreatedAt DATETIME2 NOT NULL DEFAULT SYSDATETIME(),
        CONSTRAINT FK_DonationAppointments_Donors FOREIGN KEY (DonorId) REFERENCES Donors(DonorId) ON DELETE CASCADE
    );
END;
GO

IF OBJECT_ID('DonationHistory', 'U') IS NULL
BEGIN
    CREATE TABLE DonationHistory (
        HistoryId INT IDENTITY(1,1) PRIMARY KEY,
        DonorId INT NOT NULL,
        BloodGroup NVARCHAR(5) NOT NULL,
        DonationDate DATETIME2 NOT NULL,
        Quantity INT NOT NULL CHECK (Quantity > 0),
        CONSTRAINT FK_DonationHistory_Donors FOREIGN KEY (DonorId) REFERENCES Donors(DonorId) ON DELETE CASCADE
    );
END;
GO

IF NOT EXISTS (SELECT 1 FROM Users WHERE Email = 'admin@bloodconnect.com')
BEGIN
    INSERT INTO Users (Name, Email, Password, Role)
    VALUES ('System Admin', 'admin@bloodconnect.com', 'admin123', 'Admin');
END;
GO

IF NOT EXISTS (SELECT 1 FROM BloodStock)
BEGIN
    INSERT INTO BloodStock (BloodGroup, Quantity, HospitalName)
    VALUES
    ('A+', 12, 'City General Hospital'),
    ('O-', 8, 'Red Crescent Blood Bank'),
    ('B+', 10, 'Central Medical College Hospital');
END;
GO
