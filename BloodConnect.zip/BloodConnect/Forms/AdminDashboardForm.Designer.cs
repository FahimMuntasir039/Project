namespace BloodConnect.Forms;

partial class AdminDashboardForm
{
    private System.ComponentModel.IContainer components = null;

    private Panel topPanel;
    private Label lblWelcome;
    private Button btnLogout;
    private TabControl tabControl1;
    private TabPage tabDonors;
    private TabPage tabRequests;
    private TabPage tabStock;
    private TabPage tabSchedule;
    private TabPage tabReport;
    private TextBox txtDonorFilterGroup;
    private Button btnSearchDonors;
    private Button btnDeleteDonor;
    private DataGridView dgvDonors;
    private ComboBox cmbStatusFilter;
    private TextBox txtRequestFilterGroup;
    private Button btnSearchRequests;
    private Button btnApprove;
    private Button btnReject;
    private Button btnDeleteRequest;
    private DataGridView dgvRequests;
    private TextBox txtStockGroup;
    private NumericUpDown nudStockQty;
    private TextBox txtStockHospital;
    private Button btnSaveStock;
    private Button btnRefreshStock;
    private Button btnDeleteStock;
    private DataGridView dgvStock;
    private NumericUpDown nudDonorId;
    private DateTimePicker dtpScheduleDate;
    private ComboBox cmbScheduleStatus;
    private Button btnSchedule;
    private Button btnRefreshReport;
    private ListBox lstReport;
    private Label label1;
    private Label label2;
    private Label label3;
    private Label label4;
    private Label label5;
    private Label label6;
    private Label label7;
    private Label label8;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        topPanel = new Panel();
        lblWelcome = new Label();
        btnLogout = new Button();
        tabControl1 = new TabControl();
        tabDonors = new TabPage();
        dgvDonors = new DataGridView();
        btnDeleteDonor = new Button();
        btnSearchDonors = new Button();
        txtDonorFilterGroup = new TextBox();
        label1 = new Label();
        tabRequests = new TabPage();
        dgvRequests = new DataGridView();
        btnDeleteRequest = new Button();
        btnReject = new Button();
        btnApprove = new Button();
        btnSearchRequests = new Button();
        txtRequestFilterGroup = new TextBox();
        cmbStatusFilter = new ComboBox();
        label3 = new Label();
        label2 = new Label();
        tabStock = new TabPage();
        dgvStock = new DataGridView();
        btnDeleteStock = new Button();
        btnRefreshStock = new Button();
        btnSaveStock = new Button();
        txtStockHospital = new TextBox();
        nudStockQty = new NumericUpDown();
        txtStockGroup = new TextBox();
        label6 = new Label();
        label5 = new Label();
        label4 = new Label();
        tabSchedule = new TabPage();
        btnSchedule = new Button();
        cmbScheduleStatus = new ComboBox();
        dtpScheduleDate = new DateTimePicker();
        nudDonorId = new NumericUpDown();
        label8 = new Label();
        label7 = new Label();
        tabReport = new TabPage();
        lstReport = new ListBox();
        btnRefreshReport = new Button();
        topPanel.SuspendLayout();
        tabControl1.SuspendLayout();
        tabDonors.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)dgvDonors).BeginInit();
        tabRequests.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)dgvRequests).BeginInit();
        tabStock.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)dgvStock).BeginInit();
        ((System.ComponentModel.ISupportInitialize)nudStockQty).BeginInit();
        tabSchedule.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)nudDonorId).BeginInit();
        tabReport.SuspendLayout();
        SuspendLayout();
        // 
        // topPanel
        // 
        topPanel.BackColor = Color.FromArgb(33, 37, 41);
        topPanel.Controls.Add(lblWelcome);
        topPanel.Controls.Add(btnLogout);
        topPanel.Dock = DockStyle.Top;
        topPanel.ForeColor = Color.Red;
        topPanel.Location = new Point(0, 0);
        topPanel.Name = "topPanel";
        topPanel.Size = new Size(1200, 58);
        topPanel.TabIndex = 0;
        topPanel.Paint += topPanel_Paint;
        // 
        // lblWelcome
        // 
        lblWelcome.AutoSize = true;
        lblWelcome.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
        lblWelcome.ForeColor = Color.White;
        lblWelcome.Location = new Point(16, 18);
        lblWelcome.Name = "lblWelcome";
        lblWelcome.Size = new Size(224, 21);
        lblWelcome.TabIndex = 0;
        lblWelcome.Text = "Welcome Admin Dashboard";
        // 
        // btnLogout
        // 
        btnLogout.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        btnLogout.Location = new Point(1102, 14);
        btnLogout.Name = "btnLogout";
        btnLogout.Size = new Size(80, 30);
        btnLogout.TabIndex = 1;
        btnLogout.Text = "Logout";
        btnLogout.UseVisualStyleBackColor = true;
        btnLogout.Click += btnLogout_Click;
        // 
        // tabControl1
        // 
        tabControl1.Controls.Add(tabDonors);
        tabControl1.Controls.Add(tabRequests);
        tabControl1.Controls.Add(tabStock);
        tabControl1.Controls.Add(tabSchedule);
        tabControl1.Controls.Add(tabReport);
        tabControl1.Dock = DockStyle.Fill;
        tabControl1.Location = new Point(0, 58);
        tabControl1.Name = "tabControl1";
        tabControl1.SelectedIndex = 0;
        tabControl1.Size = new Size(1200, 662);
        tabControl1.TabIndex = 1;
        // 
        // tabDonors
        // 
        tabDonors.Controls.Add(dgvDonors);
        tabDonors.Controls.Add(btnDeleteDonor);
        tabDonors.Controls.Add(btnSearchDonors);
        tabDonors.Controls.Add(txtDonorFilterGroup);
        tabDonors.Controls.Add(label1);
        tabDonors.Location = new Point(4, 24);
        tabDonors.Name = "tabDonors";
        tabDonors.Padding = new Padding(3);
        tabDonors.Size = new Size(1192, 634);
        tabDonors.TabIndex = 0;
        tabDonors.Text = "Manage Donors";
        tabDonors.UseVisualStyleBackColor = true;
        // 
        // dgvDonors
        // 
        dgvDonors.AllowUserToAddRows = false;
        dgvDonors.AllowUserToDeleteRows = false;
        dgvDonors.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        dgvDonors.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        dgvDonors.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        dgvDonors.Location = new Point(28, 67);
        dgvDonors.MultiSelect = false;
        dgvDonors.Name = "dgvDonors";
        dgvDonors.ReadOnly = true;
        dgvDonors.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        dgvDonors.Size = new Size(1137, 543);
        dgvDonors.TabIndex = 4;
        // 
        // btnDeleteDonor
        // 
        btnDeleteDonor.Location = new Point(308, 24);
        btnDeleteDonor.Name = "btnDeleteDonor";
        btnDeleteDonor.Size = new Size(150, 28);
        btnDeleteDonor.TabIndex = 3;
        btnDeleteDonor.Text = "Delete Selected Donor";
        btnDeleteDonor.UseVisualStyleBackColor = true;
        btnDeleteDonor.Click += btnDeleteDonor_Click;
        // 
        // btnSearchDonors
        // 
        btnSearchDonors.Location = new Point(220, 24);
        btnSearchDonors.Name = "btnSearchDonors";
        btnSearchDonors.Size = new Size(80, 28);
        btnSearchDonors.TabIndex = 2;
        btnSearchDonors.Text = "Search";
        btnSearchDonors.UseVisualStyleBackColor = true;
        btnSearchDonors.Click += btnSearchDonors_Click;
        // 
        // txtDonorFilterGroup
        // 
        txtDonorFilterGroup.Location = new Point(124, 27);
        txtDonorFilterGroup.Name = "txtDonorFilterGroup";
        txtDonorFilterGroup.Size = new Size(85, 23);
        txtDonorFilterGroup.TabIndex = 1;
        // 
        // label1
        // 
        label1.AutoSize = true;
        label1.Location = new Point(28, 30);
        label1.Name = "label1";
        label1.Size = new Size(74, 15);
        label1.TabIndex = 0;
        label1.Text = "Blood Group";
        // 
        // tabRequests
        // 
        tabRequests.Controls.Add(dgvRequests);
        tabRequests.Controls.Add(btnDeleteRequest);
        tabRequests.Controls.Add(btnReject);
        tabRequests.Controls.Add(btnApprove);
        tabRequests.Controls.Add(btnSearchRequests);
        tabRequests.Controls.Add(txtRequestFilterGroup);
        tabRequests.Controls.Add(cmbStatusFilter);
        tabRequests.Controls.Add(label3);
        tabRequests.Controls.Add(label2);
        tabRequests.Location = new Point(4, 24);
        tabRequests.Name = "tabRequests";
        tabRequests.Padding = new Padding(3);
        tabRequests.Size = new Size(1192, 634);
        tabRequests.TabIndex = 1;
        tabRequests.Text = "Manage Requests";
        tabRequests.UseVisualStyleBackColor = true;
        // 
        // dgvRequests
        // 
        dgvRequests.AllowUserToAddRows = false;
        dgvRequests.AllowUserToDeleteRows = false;
        dgvRequests.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        dgvRequests.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        dgvRequests.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        dgvRequests.Location = new Point(28, 67);
        dgvRequests.MultiSelect = false;
        dgvRequests.Name = "dgvRequests";
        dgvRequests.ReadOnly = true;
        dgvRequests.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        dgvRequests.Size = new Size(1137, 543);
        dgvRequests.TabIndex = 8;
        // 
        // btnDeleteRequest
        // 
        btnDeleteRequest.Location = new Point(634, 24);
        btnDeleteRequest.Name = "btnDeleteRequest";
        btnDeleteRequest.Size = new Size(120, 28);
        btnDeleteRequest.TabIndex = 7;
        btnDeleteRequest.Text = "Delete Selected";
        btnDeleteRequest.UseVisualStyleBackColor = true;
        btnDeleteRequest.Click += btnDeleteRequest_Click;
        // 
        // btnReject
        // 
        btnReject.Location = new Point(546, 24);
        btnReject.Name = "btnReject";
        btnReject.Size = new Size(80, 28);
        btnReject.TabIndex = 6;
        btnReject.Text = "Reject";
        btnReject.UseVisualStyleBackColor = true;
        btnReject.Click += btnReject_Click;
        // 
        // btnApprove
        // 
        btnApprove.Location = new Point(460, 24);
        btnApprove.Name = "btnApprove";
        btnApprove.Size = new Size(80, 28);
        btnApprove.TabIndex = 5;
        btnApprove.Text = "Approve";
        btnApprove.UseVisualStyleBackColor = true;
        btnApprove.Click += btnApprove_Click;
        // 
        // btnSearchRequests
        // 
        btnSearchRequests.Location = new Point(374, 24);
        btnSearchRequests.Name = "btnSearchRequests";
        btnSearchRequests.Size = new Size(80, 28);
        btnSearchRequests.TabIndex = 4;
        btnSearchRequests.Text = "Search";
        btnSearchRequests.UseVisualStyleBackColor = true;
        btnSearchRequests.Click += btnSearchRequests_Click;
        // 
        // txtRequestFilterGroup
        // 
        txtRequestFilterGroup.Location = new Point(270, 27);
        txtRequestFilterGroup.Name = "txtRequestFilterGroup";
        txtRequestFilterGroup.Size = new Size(90, 23);
        txtRequestFilterGroup.TabIndex = 3;
        // 
        // cmbStatusFilter
        // 
        cmbStatusFilter.DropDownStyle = ComboBoxStyle.DropDownList;
        cmbStatusFilter.FormattingEnabled = true;
        cmbStatusFilter.Items.AddRange(new object[] { "*", "Pending", "Approved", "Rejected" });
        cmbStatusFilter.Location = new Point(76, 27);
        cmbStatusFilter.Name = "cmbStatusFilter";
        cmbStatusFilter.Size = new Size(110, 23);
        cmbStatusFilter.TabIndex = 1;
        // 
        // label3
        // 
        label3.AutoSize = true;
        label3.Location = new Point(198, 30);
        label3.Name = "label3";
        label3.Size = new Size(71, 15);
        label3.TabIndex = 2;
        label3.Text = "BloodGroup";
        // 
        // label2
        // 
        label2.AutoSize = true;
        label2.Location = new Point(28, 30);
        label2.Name = "label2";
        label2.Size = new Size(39, 15);
        label2.TabIndex = 0;
        label2.Text = "Status";
        // 
        // tabStock
        // 
        tabStock.Controls.Add(dgvStock);
        tabStock.Controls.Add(btnDeleteStock);
        tabStock.Controls.Add(btnRefreshStock);
        tabStock.Controls.Add(btnSaveStock);
        tabStock.Controls.Add(txtStockHospital);
        tabStock.Controls.Add(nudStockQty);
        tabStock.Controls.Add(txtStockGroup);
        tabStock.Controls.Add(label6);
        tabStock.Controls.Add(label5);
        tabStock.Controls.Add(label4);
        tabStock.Location = new Point(4, 24);
        tabStock.Name = "tabStock";
        tabStock.Padding = new Padding(3);
        tabStock.Size = new Size(1192, 634);
        tabStock.TabIndex = 2;
        tabStock.Text = "Manage Stock";
        tabStock.UseVisualStyleBackColor = true;
        // 
        // dgvStock
        // 
        dgvStock.AllowUserToAddRows = false;
        dgvStock.AllowUserToDeleteRows = false;
        dgvStock.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        dgvStock.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        dgvStock.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        dgvStock.Location = new Point(28, 67);
        dgvStock.MultiSelect = false;
        dgvStock.Name = "dgvStock";
        dgvStock.ReadOnly = true;
        dgvStock.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        dgvStock.Size = new Size(1137, 543);
        dgvStock.TabIndex = 9;
        // 
        // btnDeleteStock
        // 
        btnDeleteStock.Location = new Point(678, 24);
        btnDeleteStock.Name = "btnDeleteStock";
        btnDeleteStock.Size = new Size(105, 28);
        btnDeleteStock.TabIndex = 8;
        btnDeleteStock.Text = "Delete Selected";
        btnDeleteStock.UseVisualStyleBackColor = true;
        btnDeleteStock.Click += btnDeleteStock_Click;
        // 
        // btnRefreshStock
        // 
        btnRefreshStock.Location = new Point(592, 24);
        btnRefreshStock.Name = "btnRefreshStock";
        btnRefreshStock.Size = new Size(80, 28);
        btnRefreshStock.TabIndex = 7;
        btnRefreshStock.Text = "Refresh";
        btnRefreshStock.UseVisualStyleBackColor = true;
        btnRefreshStock.Click += btnRefreshStock_Click;
        // 
        // btnSaveStock
        // 
        btnSaveStock.Location = new Point(506, 24);
        btnSaveStock.Name = "btnSaveStock";
        btnSaveStock.Size = new Size(80, 28);
        btnSaveStock.TabIndex = 6;
        btnSaveStock.Text = "Save";
        btnSaveStock.UseVisualStyleBackColor = true;
        btnSaveStock.Click += btnSaveStock_Click;
        // 
        // txtStockHospital
        // 
        txtStockHospital.Location = new Point(312, 27);
        txtStockHospital.Name = "txtStockHospital";
        txtStockHospital.Size = new Size(180, 23);
        txtStockHospital.TabIndex = 5;
        // 
        // nudStockQty
        // 
        nudStockQty.Location = new Point(226, 27);
        nudStockQty.Maximum = new decimal(new int[] { 100000, 0, 0, 0 });
        nudStockQty.Name = "nudStockQty";
        nudStockQty.Size = new Size(70, 23);
        nudStockQty.TabIndex = 3;
        // 
        // txtStockGroup
        // 
        txtStockGroup.Location = new Point(112, 27);
        txtStockGroup.Name = "txtStockGroup";
        txtStockGroup.Size = new Size(70, 23);
        txtStockGroup.TabIndex = 1;
        // 
        // label6
        // 
        label6.AutoSize = true;
        label6.Location = new Point(312, 30);
        label6.Name = "label6";
        label6.Size = new Size(51, 15);
        label6.TabIndex = 4;
        label6.Text = "Hospital";
        // 
        // label5
        // 
        label5.AutoSize = true;
        label5.Location = new Point(188, 30);
        label5.Name = "label5";
        label5.Size = new Size(53, 15);
        label5.TabIndex = 2;
        label5.Text = "Quantity";
        // 
        // label4
        // 
        label4.AutoSize = true;
        label4.Location = new Point(28, 30);
        label4.Name = "label4";
        label4.Size = new Size(74, 15);
        label4.TabIndex = 0;
        label4.Text = "Blood Group";
        // 
        // tabSchedule
        // 
        tabSchedule.Controls.Add(btnSchedule);
        tabSchedule.Controls.Add(cmbScheduleStatus);
        tabSchedule.Controls.Add(dtpScheduleDate);
        tabSchedule.Controls.Add(nudDonorId);
        tabSchedule.Controls.Add(label8);
        tabSchedule.Controls.Add(label7);
        tabSchedule.Location = new Point(4, 24);
        tabSchedule.Name = "tabSchedule";
        tabSchedule.Padding = new Padding(3);
        tabSchedule.Size = new Size(1192, 634);
        tabSchedule.TabIndex = 3;
        tabSchedule.Text = "Schedule";
        tabSchedule.UseVisualStyleBackColor = true;
        // 
        // btnSchedule
        // 
        btnSchedule.Location = new Point(28, 123);
        btnSchedule.Name = "btnSchedule";
        btnSchedule.Size = new Size(140, 31);
        btnSchedule.TabIndex = 5;
        btnSchedule.Text = "Schedule Appointment";
        btnSchedule.UseVisualStyleBackColor = true;
        btnSchedule.Click += btnSchedule_Click;
        // 
        // cmbScheduleStatus
        // 
        cmbScheduleStatus.DropDownStyle = ComboBoxStyle.DropDownList;
        cmbScheduleStatus.FormattingEnabled = true;
        cmbScheduleStatus.Items.AddRange(new object[] { "Pending", "Approved", "Rejected", "Completed" });
        cmbScheduleStatus.Location = new Point(242, 81);
        cmbScheduleStatus.Name = "cmbScheduleStatus";
        cmbScheduleStatus.Size = new Size(130, 23);
        cmbScheduleStatus.TabIndex = 4;
        // 
        // dtpScheduleDate
        // 
        dtpScheduleDate.Format = DateTimePickerFormat.Short;
        dtpScheduleDate.Location = new Point(128, 81);
        dtpScheduleDate.Name = "dtpScheduleDate";
        dtpScheduleDate.Size = new Size(100, 23);
        dtpScheduleDate.TabIndex = 2;
        // 
        // nudDonorId
        // 
        nudDonorId.Location = new Point(28, 81);
        nudDonorId.Maximum = new decimal(new int[] { 1000000, 0, 0, 0 });
        nudDonorId.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
        nudDonorId.Name = "nudDonorId";
        nudDonorId.Size = new Size(86, 23);
        nudDonorId.TabIndex = 1;
        nudDonorId.Value = new decimal(new int[] { 1, 0, 0, 0 });
        // 
        // label8
        // 
        label8.AutoSize = true;
        label8.Location = new Point(242, 60);
        label8.Name = "label8";
        label8.Size = new Size(39, 15);
        label8.TabIndex = 3;
        label8.Text = "Status";
        // 
        // label7
        // 
        label7.AutoSize = true;
        label7.Location = new Point(28, 60);
        label7.Name = "label7";
        label7.Size = new Size(54, 15);
        label7.TabIndex = 0;
        label7.Text = "Donor ID";
        // 
        // tabReport
        // 
        tabReport.Controls.Add(lstReport);
        tabReport.Controls.Add(btnRefreshReport);
        tabReport.Location = new Point(4, 24);
        tabReport.Name = "tabReport";
        tabReport.Padding = new Padding(3);
        tabReport.Size = new Size(1192, 634);
        tabReport.TabIndex = 4;
        tabReport.Text = "Report";
        tabReport.UseVisualStyleBackColor = true;
        // 
        // lstReport
        // 
        lstReport.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        lstReport.Font = new Font("Segoe UI", 11F);
        lstReport.FormattingEnabled = true;
        lstReport.Location = new Point(28, 67);
        lstReport.Name = "lstReport";
        lstReport.Size = new Size(1137, 544);
        lstReport.TabIndex = 1;
        // 
        // btnRefreshReport
        // 
        btnRefreshReport.Location = new Point(28, 24);
        btnRefreshReport.Name = "btnRefreshReport";
        btnRefreshReport.Size = new Size(110, 28);
        btnRefreshReport.TabIndex = 0;
        btnRefreshReport.Text = "Refresh Report";
        btnRefreshReport.UseVisualStyleBackColor = true;
        btnRefreshReport.Click += btnRefreshReport_Click;
        // 
        // AdminDashboardForm
        // 
        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(1200, 720);
        Controls.Add(tabControl1);
        Controls.Add(topPanel);
        Name = "AdminDashboardForm";
        StartPosition = FormStartPosition.CenterParent;
        Text = "Admin Dashboard";
        Load += AdminDashboardForm_Load;
        topPanel.ResumeLayout(false);
        topPanel.PerformLayout();
        tabControl1.ResumeLayout(false);
        tabDonors.ResumeLayout(false);
        tabDonors.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)dgvDonors).EndInit();
        tabRequests.ResumeLayout(false);
        tabRequests.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)dgvRequests).EndInit();
        tabStock.ResumeLayout(false);
        tabStock.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)dgvStock).EndInit();
        ((System.ComponentModel.ISupportInitialize)nudStockQty).EndInit();
        tabSchedule.ResumeLayout(false);
        tabSchedule.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)nudDonorId).EndInit();
        tabReport.ResumeLayout(false);
        ResumeLayout(false);
    }
}
