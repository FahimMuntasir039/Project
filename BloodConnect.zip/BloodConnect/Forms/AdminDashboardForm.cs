using BloodConnect.Services;

namespace BloodConnect.Forms;

public partial class AdminDashboardForm : Form
{
    private AdminService? _adminService;

    public AdminDashboardForm()
    {
        InitializeComponent();
    }

    public AdminDashboardForm(AdminService adminService) : this()
    {
        _adminService = adminService;
    }

    private void AdminDashboardForm_Load(object sender, EventArgs e)
    {
        if (_adminService is null)
        {
            return;
        }

        cmbStatusFilter.SelectedIndex = 0;
        cmbScheduleStatus.SelectedIndex = 0;

        RefreshDonors();
        RefreshRequests();
        RefreshStock();
        RefreshReport();
    }

    private bool Ready()
    {
        if (_adminService is not null)
        {
            return true;
        }

        MessageBox.Show("Admin service is not initialized.", "BloodConnect", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        return false;
    }

    private void btnSearchDonors_Click(object sender, EventArgs e)
    {
        if (Ready())
        {
            RefreshDonors();
        }
    }

    private void btnDeleteDonor_Click(object sender, EventArgs e)
    {
        if (!Ready())
        {
            return;
        }

        if (!TryGetSelectedId(dgvDonors, out var donorId))
        {
            MessageBox.Show("Select donor row first.", "BloodConnect", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        var deleted = _adminService!.DeleteDonor(donorId);
        MessageBox.Show(deleted ? "Donor deleted." : "Could not delete donor.", "BloodConnect", MessageBoxButtons.OK, deleted ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
        RefreshDonors();
    }

    private void RefreshDonors()
    {
        var group = NormalizeBlank(txtDonorFilterGroup.Text);
        var list = _adminService!.SearchDonors(group)
            .Select(x => new
            {
                Id = x.DonorId,
                x.UserId,
                x.BloodGroup,
                x.Age,
                x.Phone,
                x.Address,
                LastDonationDate = x.LastDonationDate?.ToString("yyyy-MM-dd") ?? "N/A"
            })
            .ToList();

        dgvDonors.DataSource = list;
    }

    private void btnSearchRequests_Click(object sender, EventArgs e)
    {
        if (Ready())
        {
            RefreshRequests();
        }
    }

    private void btnApprove_Click(object sender, EventArgs e)
    {
        UpdateRequestStatus("Approved");
    }

    private void btnReject_Click(object sender, EventArgs e)
    {
        UpdateRequestStatus("Rejected");
    }

    private void btnDeleteRequest_Click(object sender, EventArgs e)
    {
        if (!Ready())
        {
            return;
        }

        if (!TryGetSelectedId(dgvRequests, out var requestId))
        {
            MessageBox.Show("Select request row first.", "BloodConnect", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        var deleted = _adminService!.DeleteRequest(requestId);
        MessageBox.Show(deleted ? "Request deleted." : "Could not delete request.", "BloodConnect", MessageBoxButtons.OK, deleted ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
        RefreshRequests();
    }

    private void UpdateRequestStatus(string status)
    {
        if (!Ready())
        {
            return;
        }

        if (!TryGetSelectedId(dgvRequests, out var requestId))
        {
            MessageBox.Show("Select request row first.", "BloodConnect", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        var updated = _adminService!.UpdateRequestStatus(requestId, status);
        MessageBox.Show(updated ? $"Request marked as {status}." : "Could not update request.", "BloodConnect", MessageBoxButtons.OK, updated ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
        RefreshRequests();
    }

    private void RefreshRequests()
    {
        var status = cmbStatusFilter.SelectedItem?.ToString();
        status = status == "*" ? null : status;
        var group = NormalizeBlank(txtRequestFilterGroup.Text);

        var list = _adminService!.SearchRequests(status, group)
            .Select(x => new
            {
                Id = x.RequestId,
                x.ReceiverId,
                x.BloodGroup,
                x.Quantity,
                x.Status,
                Date = x.RequestDate.ToString("yyyy-MM-dd HH:mm")
            })
            .ToList();

        dgvRequests.DataSource = list;
    }

    private void btnSaveStock_Click(object sender, EventArgs e)
    {
        if (!Ready())
        {
            return;
        }

        if (string.IsNullOrWhiteSpace(txtStockGroup.Text) || string.IsNullOrWhiteSpace(txtStockHospital.Text))
        {
            MessageBox.Show("Stock group and hospital are required.", "BloodConnect", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        var saved = _adminService!.UpsertBloodStock(
            txtStockGroup.Text.Trim(),
            Convert.ToInt32(nudStockQty.Value),
            txtStockHospital.Text.Trim());

        MessageBox.Show(saved ? "Stock saved." : "Could not save stock.", "BloodConnect", MessageBoxButtons.OK, saved ? MessageBoxIcon.Information : MessageBoxIcon.Error);
        RefreshStock();
    }

    private void btnRefreshStock_Click(object sender, EventArgs e)
    {
        if (Ready())
        {
            RefreshStock();
        }
    }

    private void btnDeleteStock_Click(object sender, EventArgs e)
    {
        if (!Ready())
        {
            return;
        }

        if (!TryGetSelectedId(dgvStock, out var stockId))
        {
            MessageBox.Show("Select stock row first.", "BloodConnect", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        var deleted = _adminService!.DeleteBloodStock(stockId);
        MessageBox.Show(deleted ? "Stock deleted." : "Could not delete stock.", "BloodConnect", MessageBoxButtons.OK, deleted ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
        RefreshStock();
    }

    private void RefreshStock()
    {
        var list = _adminService!.GetAllBloodStock()
            .Select(x => new
            {
                Id = x.StockId,
                x.BloodGroup,
                x.Quantity,
                x.HospitalName
            })
            .ToList();

        dgvStock.DataSource = list;
    }

    private void btnSchedule_Click(object sender, EventArgs e)
    {
        if (!Ready())
        {
            return;
        }

        var status = cmbScheduleStatus.SelectedItem?.ToString() ?? "Pending";
        var ok = _adminService!.ScheduleAppointment(
            Convert.ToInt32(nudDonorId.Value),
            dtpScheduleDate.Value.Date,
            status);

        MessageBox.Show(ok ? "Appointment scheduled." : "Could not schedule appointment.", "BloodConnect", MessageBoxButtons.OK, ok ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
    }

    private void btnRefreshReport_Click(object sender, EventArgs e)
    {
        if (Ready())
        {
            RefreshReport();
        }
    }

    private void RefreshReport()
    {
        var report = _adminService!.GenerateReport();
        lstReport.DataSource = report.Select(x => $"{x.Key}: {x.Value}").ToList();
    }

    private static bool TryGetSelectedId(DataGridView grid, out int id)
    {
        id = 0;
        if (grid.CurrentRow is null || grid.CurrentRow.Cells.Count == 0)
        {
            return false;
        }

        return int.TryParse(grid.CurrentRow.Cells[0].Value?.ToString(), out id);
    }

    private static string? NormalizeBlank(string value)
    {
        var text = value.Trim();
        return string.IsNullOrWhiteSpace(text) ? null : text;
    }

    private void btnLogout_Click(object sender, EventArgs e)
    {
        Close();
    }

    private void topPanel_Paint(object sender, PaintEventArgs e)
    {

    }
}
