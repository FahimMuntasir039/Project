namespace BloodConnect.Forms;

partial class CreateAccountForm
{
    private System.ComponentModel.IContainer components = null;

    private Label lblHeader;
    private Label lblRole;
    private ComboBox cmbRole;
    private Label lblName;
    private TextBox txtName;
    private Label lblEmail;
    private TextBox txtEmail;
    private Label lblPassword;
    private TextBox txtPassword;
    private Label lblBloodGroup;
    private TextBox txtBloodGroup;
    private Label lblPhone;
    private TextBox txtPhone;
    private Label lblAddress;
    private TextBox txtAddress;
    private Label lblAge;
    private NumericUpDown nudAge;
    private Label lblLastDonation;
    private DateTimePicker dtpLastDonation;
    private Button btnCreate;
    private Button btnCancel;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        lblHeader = new Label();
        lblRole = new Label();
        cmbRole = new ComboBox();
        lblName = new Label();
        txtName = new TextBox();
        lblEmail = new Label();
        txtEmail = new TextBox();
        lblPassword = new Label();
        txtPassword = new TextBox();
        lblBloodGroup = new Label();
        txtBloodGroup = new TextBox();
        lblPhone = new Label();
        txtPhone = new TextBox();
        lblAddress = new Label();
        txtAddress = new TextBox();
        lblAge = new Label();
        nudAge = new NumericUpDown();
        lblLastDonation = new Label();
        dtpLastDonation = new DateTimePicker();
        btnCreate = new Button();
        btnCancel = new Button();
        ((System.ComponentModel.ISupportInitialize)nudAge).BeginInit();
        SuspendLayout();
        // 
        // lblHeader
        // 
        lblHeader.AutoSize = true;
        lblHeader.Font = new Font("Segoe UI", 16F, FontStyle.Bold);
        lblHeader.ForeColor = Color.FromArgb(220, 53, 69);
        lblHeader.Location = new Point(26, 19);
        lblHeader.Name = "lblHeader";
        lblHeader.Size = new Size(204, 30);
        lblHeader.TabIndex = 0;
        lblHeader.Text = "Create New Account";
        // 
        // lblRole
        // 
        lblRole.AutoSize = true;
        lblRole.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        lblRole.Location = new Point(30, 69);
        lblRole.Name = "lblRole";
        lblRole.Size = new Size(92, 19);
        lblRole.TabIndex = 1;
        lblRole.Text = "Account Type";
        // 
        // cmbRole
        // 
        cmbRole.DropDownStyle = ComboBoxStyle.DropDownList;
        cmbRole.Font = new Font("Segoe UI", 10F);
        cmbRole.FormattingEnabled = true;
        cmbRole.Items.AddRange(new object[] { "Donor", "Receiver" });
        cmbRole.Location = new Point(30, 91);
        cmbRole.Name = "cmbRole";
        cmbRole.Size = new Size(250, 25);
        cmbRole.TabIndex = 2;
        cmbRole.SelectedIndexChanged += cmbRole_SelectedIndexChanged;
        // 
        // lblName
        // 
        lblName.AutoSize = true;
        lblName.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        lblName.Location = new Point(30, 128);
        lblName.Name = "lblName";
        lblName.Size = new Size(45, 19);
        lblName.TabIndex = 3;
        lblName.Text = "Name";
        // 
        // txtName
        // 
        txtName.Font = new Font("Segoe UI", 10F);
        txtName.Location = new Point(30, 150);
        txtName.Name = "txtName";
        txtName.Size = new Size(360, 25);
        txtName.TabIndex = 4;
        // 
        // lblEmail
        // 
        lblEmail.AutoSize = true;
        lblEmail.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        lblEmail.Location = new Point(30, 186);
        lblEmail.Name = "lblEmail";
        lblEmail.Size = new Size(44, 19);
        lblEmail.TabIndex = 5;
        lblEmail.Text = "Email";
        // 
        // txtEmail
        // 
        txtEmail.Font = new Font("Segoe UI", 10F);
        txtEmail.Location = new Point(30, 208);
        txtEmail.Name = "txtEmail";
        txtEmail.Size = new Size(360, 25);
        txtEmail.TabIndex = 6;
        // 
        // lblPassword
        // 
        lblPassword.AutoSize = true;
        lblPassword.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        lblPassword.Location = new Point(30, 244);
        lblPassword.Name = "lblPassword";
        lblPassword.Size = new Size(72, 19);
        lblPassword.TabIndex = 7;
        lblPassword.Text = "Password";
        // 
        // txtPassword
        // 
        txtPassword.Font = new Font("Segoe UI", 10F);
        txtPassword.Location = new Point(30, 266);
        txtPassword.Name = "txtPassword";
        txtPassword.Size = new Size(360, 25);
        txtPassword.TabIndex = 8;
        txtPassword.UseSystemPasswordChar = true;
        // 
        // lblBloodGroup
        // 
        lblBloodGroup.AutoSize = true;
        lblBloodGroup.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        lblBloodGroup.Location = new Point(30, 302);
        lblBloodGroup.Name = "lblBloodGroup";
        lblBloodGroup.Size = new Size(86, 19);
        lblBloodGroup.TabIndex = 9;
        lblBloodGroup.Text = "Blood Group";
        // 
        // txtBloodGroup
        // 
        txtBloodGroup.Font = new Font("Segoe UI", 10F);
        txtBloodGroup.Location = new Point(30, 324);
        txtBloodGroup.Name = "txtBloodGroup";
        txtBloodGroup.Size = new Size(170, 25);
        txtBloodGroup.TabIndex = 10;
        // 
        // lblPhone
        // 
        lblPhone.AutoSize = true;
        lblPhone.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        lblPhone.Location = new Point(220, 302);
        lblPhone.Name = "lblPhone";
        lblPhone.Size = new Size(49, 19);
        lblPhone.TabIndex = 11;
        lblPhone.Text = "Phone";
        // 
        // txtPhone
        // 
        txtPhone.Font = new Font("Segoe UI", 10F);
        txtPhone.Location = new Point(220, 324);
        txtPhone.Name = "txtPhone";
        txtPhone.Size = new Size(170, 25);
        txtPhone.TabIndex = 12;
        // 
        // lblAddress
        // 
        lblAddress.AutoSize = true;
        lblAddress.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        lblAddress.Location = new Point(30, 359);
        lblAddress.Name = "lblAddress";
        lblAddress.Size = new Size(60, 19);
        lblAddress.TabIndex = 13;
        lblAddress.Text = "Address";
        // 
        // txtAddress
        // 
        txtAddress.Font = new Font("Segoe UI", 10F);
        txtAddress.Location = new Point(30, 381);
        txtAddress.Multiline = true;
        txtAddress.Name = "txtAddress";
        txtAddress.Size = new Size(360, 56);
        txtAddress.TabIndex = 14;
        // 
        // lblAge
        // 
        lblAge.AutoSize = true;
        lblAge.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        lblAge.Location = new Point(420, 128);
        lblAge.Name = "lblAge";
        lblAge.Size = new Size(33, 19);
        lblAge.TabIndex = 15;
        lblAge.Text = "Age";
        // 
        // nudAge
        // 
        nudAge.Font = new Font("Segoe UI", 10F);
        nudAge.Location = new Point(420, 150);
        nudAge.Maximum = new decimal(new int[] { 120, 0, 0, 0 });
        nudAge.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
        nudAge.Name = "nudAge";
        nudAge.Size = new Size(180, 25);
        nudAge.TabIndex = 16;
        nudAge.Value = new decimal(new int[] { 18, 0, 0, 0 });
        // 
        // lblLastDonation
        // 
        lblLastDonation.AutoSize = true;
        lblLastDonation.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        lblLastDonation.Location = new Point(420, 186);
        lblLastDonation.Name = "lblLastDonation";
        lblLastDonation.Size = new Size(121, 19);
        lblLastDonation.TabIndex = 17;
        lblLastDonation.Text = "Last Donation Date";
        // 
        // dtpLastDonation
        // 
        dtpLastDonation.Checked = false;
        dtpLastDonation.Font = new Font("Segoe UI", 10F);
        dtpLastDonation.Format = DateTimePickerFormat.Short;
        dtpLastDonation.Location = new Point(420, 208);
        dtpLastDonation.Name = "dtpLastDonation";
        dtpLastDonation.ShowCheckBox = true;
        dtpLastDonation.Size = new Size(180, 25);
        dtpLastDonation.TabIndex = 18;
        // 
        // btnCreate
        // 
        btnCreate.BackColor = Color.FromArgb(220, 53, 69);
        btnCreate.FlatAppearance.BorderSize = 0;
        btnCreate.FlatStyle = FlatStyle.Flat;
        btnCreate.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        btnCreate.ForeColor = Color.White;
        btnCreate.Location = new Point(420, 381);
        btnCreate.Name = "btnCreate";
        btnCreate.Size = new Size(180, 32);
        btnCreate.TabIndex = 19;
        btnCreate.Text = "Create Account";
        btnCreate.UseVisualStyleBackColor = false;
        btnCreate.Click += btnCreate_Click;
        // 
        // btnCancel
        // 
        btnCancel.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        btnCancel.Location = new Point(420, 420);
        btnCancel.Name = "btnCancel";
        btnCancel.Size = new Size(180, 32);
        btnCancel.TabIndex = 20;
        btnCancel.Text = "Cancel";
        btnCancel.UseVisualStyleBackColor = true;
        btnCancel.Click += btnCancel_Click;
        // 
        // CreateAccountForm
        // 
        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(640, 485);
        Controls.Add(btnCancel);
        Controls.Add(btnCreate);
        Controls.Add(dtpLastDonation);
        Controls.Add(lblLastDonation);
        Controls.Add(nudAge);
        Controls.Add(lblAge);
        Controls.Add(txtAddress);
        Controls.Add(lblAddress);
        Controls.Add(txtPhone);
        Controls.Add(lblPhone);
        Controls.Add(txtBloodGroup);
        Controls.Add(lblBloodGroup);
        Controls.Add(txtPassword);
        Controls.Add(lblPassword);
        Controls.Add(txtEmail);
        Controls.Add(lblEmail);
        Controls.Add(txtName);
        Controls.Add(lblName);
        Controls.Add(cmbRole);
        Controls.Add(lblRole);
        Controls.Add(lblHeader);
        FormBorderStyle = FormBorderStyle.FixedDialog;
        MaximizeBox = false;
        MinimizeBox = false;
        Name = "CreateAccountForm";
        StartPosition = FormStartPosition.CenterParent;
        Text = "Create New Account";
        ((System.ComponentModel.ISupportInitialize)nudAge).EndInit();
        ResumeLayout(false);
        PerformLayout();
    }
}
