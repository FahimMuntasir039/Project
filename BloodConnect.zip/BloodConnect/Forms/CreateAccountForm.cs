using BloodConnect.Models;
using BloodConnect.Services;

namespace BloodConnect.Forms;

public partial class CreateAccountForm : Form
{
    private AuthService? _authService;
    private DonorService? _donorService;
    private ReceiverService? _receiverService;

    public string CreatedEmail { get; private set; } = string.Empty;

    public CreateAccountForm()
    {
        InitializeComponent();
        cmbRole.SelectedIndex = 0;
        UpdateRoleFields();
    }

    public CreateAccountForm(
        AuthService authService,
        DonorService donorService,
        ReceiverService receiverService) : this()
    {
        _authService = authService;
        _donorService = donorService;
        _receiverService = receiverService;
    }

    private void cmbRole_SelectedIndexChanged(object sender, EventArgs e)
    {
        UpdateRoleFields();
    }

    private void UpdateRoleFields()
    {
        var isDonor = SelectedRole == Roles.Donor;
        lblBloodGroup.Text = isDonor ? "Blood Group" : "Blood Group Needed";

        lblAge.Visible = isDonor;
        nudAge.Visible = isDonor;
        lblLastDonation.Visible = isDonor;
        dtpLastDonation.Visible = isDonor;

        if (!isDonor)
        {
            dtpLastDonation.Checked = false;
        }
    }

    private string SelectedRole => cmbRole.SelectedItem?.ToString() ?? Roles.Receiver;

    private void btnCreate_Click(object sender, EventArgs e)
    {
        if (_authService is null || _donorService is null || _receiverService is null)
        {
            MessageBox.Show("Services are not initialized.", "BloodConnect", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        var role = SelectedRole;
        var name = txtName.Text.Trim();
        var email = txtEmail.Text.Trim();
        var password = txtPassword.Text;
        var bloodGroup = txtBloodGroup.Text.Trim();
        var phone = txtPhone.Text.Trim();
        var address = txtAddress.Text.Trim();

        if (HasAnyBlank(name, email, password, bloodGroup, phone, address))
        {
            MessageBox.Show("Please fill all required fields.", "BloodConnect", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        var userId = _authService.RegisterUser(name, email, password, role);
        if (userId < 0)
        {
            MessageBox.Show("Email already exists.", "BloodConnect", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        bool profileSaved;

        if (role == Roles.Donor)
        {
            profileSaved = _donorService.UpsertDonorProfile(
                userId,
                bloodGroup,
                Convert.ToInt32(nudAge.Value),
                phone,
                address,
                dtpLastDonation.Checked ? dtpLastDonation.Value.Date : null);
        }
        else
        {
            profileSaved = _receiverService.UpsertReceiverProfile(
                userId,
                bloodGroup,
                phone,
                address);
        }

        if (!profileSaved)
        {
            MessageBox.Show("Account created, but profile could not be saved.", "BloodConnect", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        CreatedEmail = email;
        DialogResult = DialogResult.OK;
        Close();
    }

    private void btnCancel_Click(object sender, EventArgs e)
    {
        DialogResult = DialogResult.Cancel;
        Close();
    }

    private static bool HasAnyBlank(params string[] values)
    {
        return values.Any(string.IsNullOrWhiteSpace);
    }
}
