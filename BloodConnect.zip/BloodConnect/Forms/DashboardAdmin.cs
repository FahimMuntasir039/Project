namespace BloodConnect.Forms;

public partial class DashboardForm
{
    private void BuildAdminTabs()
    {
        _tabs.TabPages.Add(CreateAdminDonorsTab());
        _tabs.TabPages.Add(CreateAdminRequestsTab());
        _tabs.TabPages.Add(CreateAdminStockTab());
        _tabs.TabPages.Add(CreateAdminScheduleTab());
        _tabs.TabPages.Add(CreateAdminReportTab());

        RunSafe(() =>
        {
            RefreshAdminDonors();
            RefreshAdminRequests();
            RefreshAdminStock();
            RefreshAdminReports();
        });
    }

    private TabPage CreateAdminDonorsTab()
    {
        var page = new TabPage("Manage Donors");

        var top = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            Padding = new Padding(12),
            WrapContents = true
        };

        _adminDonorFilterGroup = CreateTextBox(width: 120);
        var search = CreatePrimaryButton("Search");
        search.Click += (_, _) => RunSafe(RefreshAdminDonors);

        var delete = CreateDangerButton("Delete Selected Donor");
        delete.Click += (_, _) => RunSafe(DeleteAdminSelectedDonor);

        top.Controls.Add(new Label { Text = "Blood Group Filter", AutoSize = true, Padding = new Padding(0, 8, 0, 0) });
        top.Controls.Add(_adminDonorFilterGroup);
        top.Controls.Add(search);
        top.Controls.Add(delete);

        _adminDonorsGrid = CreateReadOnlyGrid();
        _adminDonorsGrid.Dock = DockStyle.Fill;

        page.Controls.Add(_adminDonorsGrid);
        page.Controls.Add(top);
        return page;
    }

    private TabPage CreateAdminRequestsTab()
    {
        var page = new TabPage("Manage Requests");

        var top = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            Padding = new Padding(12),
            WrapContents = true
        };

        _adminRequestFilterStatus = new ComboBox
        {
            Width = 130,
            Font = new Font("Segoe UI", 10),
            DropDownStyle = ComboBoxStyle.DropDownList
        };
        _adminRequestFilterStatus.Items.AddRange(new object[] { "*", "Pending", "Approved", "Rejected" });
        _adminRequestFilterStatus.SelectedIndex = 0;

        _adminRequestFilterGroup = CreateTextBox(width: 120);

        var search = CreatePrimaryButton("Search");
        search.Click += (_, _) => RunSafe(RefreshAdminRequests);

        var approve = CreateNeutralButton("Approve Selected");
        approve.Click += (_, _) => RunSafe(() => UpdateAdminSelectedRequestStatus("Approved"));

        var reject = CreateNeutralButton("Reject Selected");
        reject.Click += (_, _) => RunSafe(() => UpdateAdminSelectedRequestStatus("Rejected"));

        var delete = CreateDangerButton("Delete Selected");
        delete.Click += (_, _) => RunSafe(DeleteAdminSelectedRequest);

        top.Controls.Add(new Label { Text = "Status", AutoSize = true, Padding = new Padding(0, 8, 0, 0) });
        top.Controls.Add(_adminRequestFilterStatus);
        top.Controls.Add(new Label { Text = "Blood Group", AutoSize = true, Padding = new Padding(8, 8, 0, 0) });
        top.Controls.Add(_adminRequestFilterGroup);
        top.Controls.Add(search);
        top.Controls.Add(approve);
        top.Controls.Add(reject);
        top.Controls.Add(delete);

        _adminRequestsGrid = CreateReadOnlyGrid();
        _adminRequestsGrid.Dock = DockStyle.Fill;

        page.Controls.Add(_adminRequestsGrid);
        page.Controls.Add(top);
        return page;
    }

    private TabPage CreateAdminStockTab()
    {
        var page = new TabPage("Manage Blood Stock");

        var top = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            Padding = new Padding(12),
            WrapContents = true
        };

        _adminStockGroup = CreateTextBox(width: 100);
        _adminStockQuantity = CreateNumber(0, 100000, 0);
        _adminStockHospital = CreateTextBox(width: 180);

        var save = CreatePrimaryButton("Add/Update Stock");
        save.Click += (_, _) => RunSafe(SaveAdminStock);

        var refresh = CreateNeutralButton("Refresh");
        refresh.Click += (_, _) => RunSafe(RefreshAdminStock);

        var delete = CreateDangerButton("Delete Selected");
        delete.Click += (_, _) => RunSafe(DeleteAdminSelectedStock);

        top.Controls.Add(new Label { Text = "Group", AutoSize = true, Padding = new Padding(0, 8, 0, 0) });
        top.Controls.Add(_adminStockGroup);
        top.Controls.Add(new Label { Text = "Quantity", AutoSize = true, Padding = new Padding(8, 8, 0, 0) });
        top.Controls.Add(_adminStockQuantity);
        top.Controls.Add(new Label { Text = "Hospital", AutoSize = true, Padding = new Padding(8, 8, 0, 0) });
        top.Controls.Add(_adminStockHospital);
        top.Controls.Add(save);
        top.Controls.Add(refresh);
        top.Controls.Add(delete);

        _adminStockGrid = CreateReadOnlyGrid();
        _adminStockGrid.Dock = DockStyle.Fill;

        page.Controls.Add(_adminStockGrid);
        page.Controls.Add(top);
        return page;
    }

    private TabPage CreateAdminScheduleTab()
    {
        var page = new TabPage("Schedule Appointments");
        var table = CreateFormTable();

        _adminScheduleDonorId = CreateNumber(1, int.MaxValue, 1);
        _adminScheduleDate = new DateTimePicker
        {
            Format = DateTimePickerFormat.Short,
            Width = 200,
            Font = new Font("Segoe UI", 10)
        };
        _adminScheduleStatus = new ComboBox
        {
            Width = 200,
            Font = new Font("Segoe UI", 10),
            DropDownStyle = ComboBoxStyle.DropDownList
        };
        _adminScheduleStatus.Items.AddRange(new object[] { "Pending", "Approved", "Rejected", "Completed" });
        _adminScheduleStatus.SelectedIndex = 0;

        AddLabeledControl(table, 0, "Donor ID", _adminScheduleDonorId);
        AddLabeledControl(table, 1, "Appointment Date", _adminScheduleDate);
        AddLabeledControl(table, 2, "Status", _adminScheduleStatus);

        var schedule = CreatePrimaryButton("Schedule Appointment");
        schedule.Click += (_, _) => RunSafe(ScheduleAdminAppointment);
        AddFullRowControl(table, 3, schedule);

        AddFullRowControl(
            table,
            4,
            CreateInfoLabel("Tip: Use Donor ID from 'Manage Donors' tab."));

        page.Controls.Add(CreateScrollContainer(table));
        return page;
    }

    private TabPage CreateAdminReportTab()
    {
        var page = new TabPage("Reports");

        var top = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            Padding = new Padding(12)
        };

        var refresh = CreateNeutralButton("Refresh Report");
        refresh.Click += (_, _) => RunSafe(RefreshAdminReports);
        top.Controls.Add(refresh);

        _adminReportList = new ListBox
        {
            Dock = DockStyle.Fill,
            Font = new Font("Segoe UI", 11),
            IntegralHeight = false
        };

        page.Controls.Add(_adminReportList);
        page.Controls.Add(top);
        return page;
    }

    private void RefreshAdminDonors()
    {
        var filter = NormalizeBlank(_adminDonorFilterGroup.Text);
        var donors = _adminService.SearchDonors(filter)
            .Select(d => new
            {
                Id = d.DonorId,
                d.UserId,
                d.BloodGroup,
                d.Age,
                d.Phone,
                d.Address,
                LastDonationDate = d.LastDonationDate?.ToString("yyyy-MM-dd") ?? "N/A"
            })
            .ToList();

        _adminDonorsGrid.DataSource = donors;
    }

    private void DeleteAdminSelectedDonor()
    {
        if (!TryGetSelectedId(_adminDonorsGrid, out var donorId))
        {
            ShowWarning("Select a donor row first.");
            return;
        }

        var deleted = _adminService.DeleteDonor(donorId);
        if (!deleted)
        {
            ShowWarning("Donor not found.");
            return;
        }

        ShowInfo("Donor deleted.");
        RefreshAdminDonors();
    }

    private void RefreshAdminRequests()
    {
        var status = _adminRequestFilterStatus.SelectedItem?.ToString();
        status = status == "*" ? null : status;
        var group = NormalizeBlank(_adminRequestFilterGroup.Text);

        var requests = _adminService.SearchRequests(status, group)
            .Select(r => new
            {
                Id = r.RequestId,
                r.ReceiverId,
                r.BloodGroup,
                r.Quantity,
                r.Status,
                Date = r.RequestDate.ToString("yyyy-MM-dd HH:mm")
            })
            .ToList();

        _adminRequestsGrid.DataSource = requests;
    }

    private void UpdateAdminSelectedRequestStatus(string newStatus)
    {
        if (!TryGetSelectedId(_adminRequestsGrid, out var requestId))
        {
            ShowWarning("Select a request row first.");
            return;
        }

        var updated = _adminService.UpdateRequestStatus(requestId, newStatus);
        if (!updated)
        {
            ShowWarning("Could not update request status.");
            return;
        }

        ShowInfo($"Request marked as {newStatus}.");
        RefreshAdminRequests();
    }

    private void DeleteAdminSelectedRequest()
    {
        if (!TryGetSelectedId(_adminRequestsGrid, out var requestId))
        {
            ShowWarning("Select a request row first.");
            return;
        }

        var deleted = _adminService.DeleteRequest(requestId);
        if (!deleted)
        {
            ShowWarning("Request not found.");
            return;
        }

        ShowInfo("Request deleted.");
        RefreshAdminRequests();
    }

    private void SaveAdminStock()
    {
        var group = _adminStockGroup.Text.Trim();
        var hospital = _adminStockHospital.Text.Trim();
        var quantity = Convert.ToInt32(_adminStockQuantity.Value);

        if (HasAnyBlank(group, hospital))
        {
            ShowWarning("Blood group and hospital are required.");
            return;
        }

        var saved = _adminService.UpsertBloodStock(group, quantity, hospital);
        if (!saved)
        {
            ShowWarning("Could not save blood stock.");
            return;
        }

        ShowInfo("Blood stock saved.");
        RefreshAdminStock();
    }

    private void RefreshAdminStock()
    {
        var stock = _adminService.GetAllBloodStock()
            .Select(s => new
            {
                Id = s.StockId,
                s.BloodGroup,
                s.Quantity,
                s.HospitalName
            })
            .ToList();

        _adminStockGrid.DataSource = stock;
    }

    private void DeleteAdminSelectedStock()
    {
        if (!TryGetSelectedId(_adminStockGrid, out var stockId))
        {
            ShowWarning("Select a stock row first.");
            return;
        }

        var deleted = _adminService.DeleteBloodStock(stockId);
        if (!deleted)
        {
            ShowWarning("Stock not found.");
            return;
        }

        ShowInfo("Stock entry deleted.");
        RefreshAdminStock();
    }

    private void ScheduleAdminAppointment()
    {
        var donorId = Convert.ToInt32(_adminScheduleDonorId.Value);
        var date = _adminScheduleDate.Value.Date;
        var status = _adminScheduleStatus.SelectedItem?.ToString() ?? "Pending";

        var scheduled = _adminService.ScheduleAppointment(donorId, date, status);
        if (!scheduled)
        {
            ShowWarning("Could not schedule appointment. Verify Donor ID.");
            return;
        }

        ShowInfo("Appointment scheduled.");
    }

    private void RefreshAdminReports()
    {
        var report = _adminService.GenerateReport();
        _adminReportList.DataSource = report.Select(item => $"{item.Key}: {item.Value}").ToList();
    }
}
