namespace BloodConnect.Forms;

public partial class DashboardForm
{
    private void BuildDonorTabs()
    {
        _tabs.TabPages.Add(CreateDonorProfileTab());
        _tabs.TabPages.Add(CreateDonorEligibilityTab());
        _tabs.TabPages.Add(CreateDonorAppointmentsTab());
        _tabs.TabPages.Add(CreateDonorHistoryTab());
        _tabs.TabPages.Add(CreateDonorUrgentTab());

        RunSafe(() =>
        {
            LoadDonorProfile();
            RefreshDonorAppointments();
            RefreshDonorHistory();
            RefreshDonorUrgentRequests();
        });
    }

    private TabPage CreateDonorProfileTab()
    {
        var page = new TabPage("Profile");
        var table = CreateFormTable();

        _donorBloodGroup = CreateTextBox();
        _donorAge = CreateNumber(1, 120, 18);
        _donorPhone = CreateTextBox();
        _donorAddress = CreateTextBox(multiline: true);
        _donorLastDonation = new DateTimePicker
        {
            Format = DateTimePickerFormat.Short,
            ShowCheckBox = true,
            Checked = false,
            Width = 240,
            Font = new Font("Segoe UI", 10)
        };

        AddLabeledControl(table, 0, "Blood Group", _donorBloodGroup);
        AddLabeledControl(table, 1, "Age", _donorAge);
        AddLabeledControl(table, 2, "Phone", _donorPhone);
        AddLabeledControl(table, 3, "Address", _donorAddress);
        AddLabeledControl(table, 4, "Last Donation Date", _donorLastDonation);

        var save = CreatePrimaryButton("Save Profile");
        save.Click += (_, _) => RunSafe(SaveDonorProfile);
        AddFullRowControl(table, 5, save);

        page.Controls.Add(CreateScrollContainer(table));
        return page;
    }

    private TabPage CreateDonorEligibilityTab()
    {
        var page = new TabPage("Eligibility");
        var panel = new Panel { Dock = DockStyle.Fill, Padding = new Padding(24) };

        var check = CreatePrimaryButton("Check Eligibility");
        check.Click += (_, _) => RunSafe(CheckDonorEligibility);

        _donorEligibilityLabel = new Label
        {
            AutoSize = true,
            Font = new Font("Segoe UI", 11),
            Margin = new Padding(0, 16, 0, 0),
            Text = "Click the button to check eligibility."
        };

        var stack = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            FlowDirection = FlowDirection.TopDown,
            WrapContents = false
        };

        stack.Controls.Add(check);
        stack.Controls.Add(_donorEligibilityLabel);
        panel.Controls.Add(stack);

        page.Controls.Add(panel);
        return page;
    }

    private TabPage CreateDonorAppointmentsTab()
    {
        var page = new TabPage("Appointments");

        var top = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            Padding = new Padding(12),
            WrapContents = true
        };

        _donorAppointmentDate = new DateTimePicker
        {
            Format = DateTimePickerFormat.Short,
            Width = 140,
            Font = new Font("Segoe UI", 10)
        };

        var request = CreatePrimaryButton("Request Appointment");
        request.Click += (_, _) => RunSafe(RequestDonorAppointment);

        var refresh = CreateNeutralButton("Refresh");
        refresh.Click += (_, _) => RunSafe(RefreshDonorAppointments);

        var deletePending = CreateDangerButton("Delete Selected Pending");
        deletePending.Click += (_, _) => RunSafe(DeleteDonorPendingAppointment);

        top.Controls.Add(new Label { Text = "Appointment Date", AutoSize = true, Padding = new Padding(0, 8, 0, 0) });
        top.Controls.Add(_donorAppointmentDate);
        top.Controls.Add(request);
        top.Controls.Add(refresh);
        top.Controls.Add(deletePending);

        _donorAppointmentsGrid = CreateReadOnlyGrid();
        _donorAppointmentsGrid.Dock = DockStyle.Fill;

        page.Controls.Add(_donorAppointmentsGrid);
        page.Controls.Add(top);
        return page;
    }

    private TabPage CreateDonorHistoryTab()
    {
        var page = new TabPage("Donation History");

        var top = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            Padding = new Padding(12)
        };

        var refresh = CreateNeutralButton("Refresh History");
        refresh.Click += (_, _) => RunSafe(RefreshDonorHistory);
        top.Controls.Add(refresh);

        _donorHistoryGrid = CreateReadOnlyGrid();
        _donorHistoryGrid.Dock = DockStyle.Fill;

        page.Controls.Add(_donorHistoryGrid);
        page.Controls.Add(top);
        return page;
    }

    private TabPage CreateDonorUrgentTab()
    {
        var page = new TabPage("Urgent Needs");

        var top = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            Padding = new Padding(12)
        };

        var refresh = CreateNeutralButton("Refresh Urgent Requests");
        refresh.Click += (_, _) => RunSafe(RefreshDonorUrgentRequests);
        top.Controls.Add(refresh);

        _donorUrgentGrid = CreateReadOnlyGrid();
        _donorUrgentGrid.Dock = DockStyle.Fill;

        page.Controls.Add(_donorUrgentGrid);
        page.Controls.Add(top);
        return page;
    }

    private void LoadDonorProfile()
    {
        var donor = _donorService.GetDonorByUserId(_user.UserId);
        if (donor is null)
        {
            ShowWarning("Donor profile not found. Please complete profile details.");
            return;
        }

        _donorBloodGroup.Text = donor.BloodGroup;
        _donorAge.Value = donor.Age;
        _donorPhone.Text = donor.Phone;
        _donorAddress.Text = donor.Address;

        if (donor.LastDonationDate.HasValue)
        {
            _donorLastDonation.Value = donor.LastDonationDate.Value;
            _donorLastDonation.Checked = true;
        }
        else
        {
            _donorLastDonation.Checked = false;
        }
    }

    private void SaveDonorProfile()
    {
        if (HasAnyBlank(_donorBloodGroup.Text, _donorPhone.Text, _donorAddress.Text))
        {
            ShowWarning("Please fill all profile fields.");
            return;
        }

        var saved = _donorService.UpsertDonorProfile(
            _user.UserId,
            _donorBloodGroup.Text.Trim(),
            Convert.ToInt32(_donorAge.Value),
            _donorPhone.Text.Trim(),
            _donorAddress.Text.Trim(),
            _donorLastDonation.Checked ? _donorLastDonation.Value.Date : null);

        if (!saved)
        {
            ShowError("Could not save donor profile.");
            return;
        }

        ShowInfo("Donor profile saved.");
    }

    private void CheckDonorEligibility()
    {
        var donor = _donorService.GetDonorByUserId(_user.UserId);
        if (donor is null)
        {
            _donorEligibilityLabel.Text = "Profile not found. Save profile first.";
            return;
        }

        var result = _donorService.CheckEligibility(donor.DonorId);
        _donorEligibilityLabel.Text = $"Eligible: {(result.IsEligible ? "Yes" : "No")}. {result.Reason}";
    }

    private void RequestDonorAppointment()
    {
        var donor = _donorService.GetDonorByUserId(_user.UserId);
        if (donor is null)
        {
            ShowWarning("Profile not found. Save donor profile first.");
            return;
        }

        var ok = _donorService.RequestAppointment(donor.DonorId, _donorAppointmentDate.Value.Date);
        if (!ok)
        {
            ShowError("Could not request appointment.");
            return;
        }

        ShowInfo("Appointment request submitted.");
        RefreshDonorAppointments();
    }

    private void RefreshDonorAppointments()
    {
        var donor = _donorService.GetDonorByUserId(_user.UserId);
        if (donor is null)
        {
            _donorAppointmentsGrid.DataSource = null;
            return;
        }

        var list = _donorService.GetAppointments(donor.DonorId)
            .Select(a => new
            {
                Id = a.AppointmentId,
                Date = a.AppointmentDate.ToString("yyyy-MM-dd"),
                a.Status,
                CreatedAt = a.CreatedAt.ToString("yyyy-MM-dd HH:mm")
            })
            .ToList();

        _donorAppointmentsGrid.DataSource = list;
    }

    private void DeleteDonorPendingAppointment()
    {
        var donor = _donorService.GetDonorByUserId(_user.UserId);
        if (donor is null)
        {
            ShowWarning("Profile not found.");
            return;
        }

        if (!TryGetSelectedId(_donorAppointmentsGrid, out var appointmentId))
        {
            ShowWarning("Select an appointment row first.");
            return;
        }

        var deleted = _donorService.DeletePendingAppointment(donor.DonorId, appointmentId);
        if (!deleted)
        {
            ShowWarning("Appointment not found or not pending.");
            return;
        }

        ShowInfo("Pending appointment deleted.");
        RefreshDonorAppointments();
    }

    private void RefreshDonorHistory()
    {
        var donor = _donorService.GetDonorByUserId(_user.UserId);
        if (donor is null)
        {
            _donorHistoryGrid.DataSource = null;
            return;
        }

        var list = _donorService.GetDonationHistory(donor.DonorId)
            .Select(h => new
            {
                Id = h.HistoryId,
                Date = h.DonationDate.ToString("yyyy-MM-dd"),
                h.BloodGroup,
                h.Quantity
            })
            .ToList();

        _donorHistoryGrid.DataSource = list;
    }

    private void RefreshDonorUrgentRequests()
    {
        var list = _donorService.GetUrgentRequests()
            .Select(r => new
            {
                Id = r.RequestId,
                r.BloodGroup,
                r.Quantity,
                r.Status,
                Date = r.RequestDate.ToString("yyyy-MM-dd HH:mm")
            })
            .ToList();

        _donorUrgentGrid.DataSource = list;
    }

    private void BuildReceiverTabs()
    {
        _tabs.TabPages.Add(CreateReceiverProfileTab());
        _tabs.TabPages.Add(CreateReceiverSearchTab());
        _tabs.TabPages.Add(CreateReceiverRequestsTab());
        _tabs.TabPages.Add(CreateReceiverHospitalsTab());

        RunSafe(() =>
        {
            LoadReceiverProfile();
            RefreshReceiverRequests();
            RefreshReceiverHospitals();
        });
    }

    private TabPage CreateReceiverProfileTab()
    {
        var page = new TabPage("Profile");
        var table = CreateFormTable();

        _receiverBloodGroup = CreateTextBox();
        _receiverPhone = CreateTextBox();
        _receiverAddress = CreateTextBox(multiline: true);

        AddLabeledControl(table, 0, "Blood Group Needed", _receiverBloodGroup);
        AddLabeledControl(table, 1, "Phone", _receiverPhone);
        AddLabeledControl(table, 2, "Address", _receiverAddress);

        var save = CreatePrimaryButton("Save Profile");
        save.Click += (_, _) => RunSafe(SaveReceiverProfile);
        AddFullRowControl(table, 3, save);

        page.Controls.Add(CreateScrollContainer(table));
        return page;
    }

    private TabPage CreateReceiverSearchTab()
    {
        var page = new TabPage("Search Blood Stock");

        var top = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            Padding = new Padding(12),
            WrapContents = true
        };

        _receiverSearchGroup = CreateTextBox(width: 120);
        _receiverSearchLocation = CreateTextBox(width: 180);
        var search = CreatePrimaryButton("Search");
        search.Click += (_, _) => RunSafe(SearchReceiverStock);

        top.Controls.Add(new Label { Text = "Blood Group", AutoSize = true, Padding = new Padding(0, 8, 0, 0) });
        top.Controls.Add(_receiverSearchGroup);
        top.Controls.Add(new Label { Text = "Location/Hospital", AutoSize = true, Padding = new Padding(8, 8, 0, 0) });
        top.Controls.Add(_receiverSearchLocation);
        top.Controls.Add(search);

        _receiverStockGrid = CreateReadOnlyGrid();
        _receiverStockGrid.Dock = DockStyle.Fill;

        page.Controls.Add(_receiverStockGrid);
        page.Controls.Add(top);
        return page;
    }

    private TabPage CreateReceiverRequestsTab()
    {
        var page = new TabPage("Blood Requests");

        var top = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            Padding = new Padding(12),
            WrapContents = true
        };

        _receiverRequestGroup = CreateTextBox(width: 120);
        _receiverRequestQuantity = CreateNumber(1, 100, 1);

        var send = CreatePrimaryButton("Send Request");
        send.Click += (_, _) => RunSafe(SendReceiverRequest);

        var refresh = CreateNeutralButton("Refresh");
        refresh.Click += (_, _) => RunSafe(RefreshReceiverRequests);

        var deletePending = CreateDangerButton("Delete Selected Pending");
        deletePending.Click += (_, _) => RunSafe(DeleteReceiverPendingRequest);

        top.Controls.Add(new Label { Text = "Blood Group", AutoSize = true, Padding = new Padding(0, 8, 0, 0) });
        top.Controls.Add(_receiverRequestGroup);
        top.Controls.Add(new Label { Text = "Quantity", AutoSize = true, Padding = new Padding(8, 8, 0, 0) });
        top.Controls.Add(_receiverRequestQuantity);
        top.Controls.Add(send);
        top.Controls.Add(refresh);
        top.Controls.Add(deletePending);

        _receiverRequestsGrid = CreateReadOnlyGrid();
        _receiverRequestsGrid.Dock = DockStyle.Fill;

        page.Controls.Add(_receiverRequestsGrid);
        page.Controls.Add(top);
        return page;
    }

    private TabPage CreateReceiverHospitalsTab()
    {
        var page = new TabPage("Hospitals/Blood Banks");

        var top = new FlowLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            Padding = new Padding(12)
        };

        var refresh = CreateNeutralButton("Refresh Hospitals");
        refresh.Click += (_, _) => RunSafe(RefreshReceiverHospitals);

        top.Controls.Add(refresh);

        _receiverHospitalsList = new ListBox
        {
            Dock = DockStyle.Fill,
            Font = new Font("Segoe UI", 11),
            IntegralHeight = false
        };

        page.Controls.Add(_receiverHospitalsList);
        page.Controls.Add(top);
        return page;
    }

    private void LoadReceiverProfile()
    {
        var receiver = _receiverService.GetReceiverByUserId(_user.UserId);
        if (receiver is null)
        {
            return;
        }

        _receiverBloodGroup.Text = receiver.BloodGroupNeeded;
        _receiverPhone.Text = receiver.Phone;
        _receiverAddress.Text = receiver.Address;
    }

    private void SaveReceiverProfile()
    {
        if (HasAnyBlank(_receiverBloodGroup.Text, _receiverPhone.Text, _receiverAddress.Text))
        {
            ShowWarning("Please fill all profile fields.");
            return;
        }

        var saved = _receiverService.UpsertReceiverProfile(
            _user.UserId,
            _receiverBloodGroup.Text.Trim(),
            _receiverPhone.Text.Trim(),
            _receiverAddress.Text.Trim());

        if (!saved)
        {
            ShowError("Could not save receiver profile.");
            return;
        }

        ShowInfo("Receiver profile saved.");
    }

    private void SearchReceiverStock()
    {
        var bloodGroup = NormalizeBlank(_receiverSearchGroup.Text);
        var location = NormalizeBlank(_receiverSearchLocation.Text);

        var list = _receiverService.SearchBloodStock(bloodGroup, location)
            .Select(s => new
            {
                Id = s.StockId,
                s.BloodGroup,
                s.Quantity,
                s.HospitalName
            })
            .ToList();

        _receiverStockGrid.DataSource = list;
    }

    private void SendReceiverRequest()
    {
        var receiver = _receiverService.GetReceiverByUserId(_user.UserId);
        if (receiver is null)
        {
            ShowWarning("Profile not found. Save receiver profile first.");
            return;
        }

        var group = _receiverRequestGroup.Text.Trim();
        if (string.IsNullOrWhiteSpace(group))
        {
            ShowWarning("Blood group is required.");
            return;
        }

        var ok = _receiverService.SendBloodRequest(receiver.ReceiverId, group, Convert.ToInt32(_receiverRequestQuantity.Value));
        if (!ok)
        {
            ShowError("Could not send request.");
            return;
        }

        ShowInfo("Blood request sent.");
        RefreshReceiverRequests();
    }

    private void RefreshReceiverRequests()
    {
        var receiver = _receiverService.GetReceiverByUserId(_user.UserId);
        if (receiver is null)
        {
            _receiverRequestsGrid.DataSource = null;
            return;
        }

        var list = _receiverService.GetRequestsByReceiver(receiver.ReceiverId)
            .Select(r => new
            {
                Id = r.RequestId,
                r.BloodGroup,
                r.Quantity,
                r.Status,
                Date = r.RequestDate.ToString("yyyy-MM-dd HH:mm")
            })
            .ToList();

        _receiverRequestsGrid.DataSource = list;
    }

    private void DeleteReceiverPendingRequest()
    {
        var receiver = _receiverService.GetReceiverByUserId(_user.UserId);
        if (receiver is null)
        {
            ShowWarning("Profile not found.");
            return;
        }

        if (!TryGetSelectedId(_receiverRequestsGrid, out var requestId))
        {
            ShowWarning("Select a request row first.");
            return;
        }

        var deleted = _receiverService.DeletePendingRequest(receiver.ReceiverId, requestId);
        if (!deleted)
        {
            ShowWarning("Request not found or not pending.");
            return;
        }

        ShowInfo("Pending request deleted.");
        RefreshReceiverRequests();
    }

    private void RefreshReceiverHospitals()
    {
        var hospitals = _receiverService.GetAvailableHospitals();
        _receiverHospitalsList.DataSource = hospitals.ToList();
    }
}
