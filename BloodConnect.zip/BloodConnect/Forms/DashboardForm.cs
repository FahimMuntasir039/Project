using BloodConnect.Models;
using BloodConnect.Services;

namespace BloodConnect.Forms;

public partial class DashboardForm : Form
{
    private readonly User _user;
    private readonly DonorService _donorService;
    private readonly ReceiverService _receiverService;
    private readonly AdminService _adminService;

    private readonly TabControl _tabs;

    private TextBox _donorBloodGroup = null!;
    private NumericUpDown _donorAge = null!;
    private TextBox _donorPhone = null!;
    private TextBox _donorAddress = null!;
    private DateTimePicker _donorLastDonation = null!;
    private Label _donorEligibilityLabel = null!;
    private DateTimePicker _donorAppointmentDate = null!;
    private DataGridView _donorAppointmentsGrid = null!;
    private DataGridView _donorHistoryGrid = null!;
    private DataGridView _donorUrgentGrid = null!;

    private TextBox _receiverBloodGroup = null!;
    private TextBox _receiverPhone = null!;
    private TextBox _receiverAddress = null!;
    private TextBox _receiverSearchGroup = null!;
    private TextBox _receiverSearchLocation = null!;
    private DataGridView _receiverStockGrid = null!;
    private TextBox _receiverRequestGroup = null!;
    private NumericUpDown _receiverRequestQuantity = null!;
    private DataGridView _receiverRequestsGrid = null!;
    private ListBox _receiverHospitalsList = null!;

    private TextBox _adminDonorFilterGroup = null!;
    private DataGridView _adminDonorsGrid = null!;
    private ComboBox _adminRequestFilterStatus = null!;
    private TextBox _adminRequestFilterGroup = null!;
    private DataGridView _adminRequestsGrid = null!;
    private TextBox _adminStockGroup = null!;
    private NumericUpDown _adminStockQuantity = null!;
    private TextBox _adminStockHospital = null!;
    private DataGridView _adminStockGrid = null!;
    private NumericUpDown _adminScheduleDonorId = null!;
    private DateTimePicker _adminScheduleDate = null!;
    private ComboBox _adminScheduleStatus = null!;
    private ListBox _adminReportList = null!;

    public DashboardForm(
        User user,
        DonorService donorService,
        ReceiverService receiverService,
        AdminService adminService)
    {
        _user = user;
        _donorService = donorService;
        _receiverService = receiverService;
        _adminService = adminService;

        Text = $"BloodConnect - {_user.Role} Dashboard";
        StartPosition = FormStartPosition.CenterParent;
        Width = 1200;
        Height = 760;
        MinimumSize = new Size(1100, 700);

        var header = CreateHeader();

        _tabs = new TabControl
        {
            Dock = DockStyle.Fill
        };

        BuildRoleTabs();

        Controls.Add(_tabs);
        Controls.Add(header);
    }

    private Control CreateHeader()
    {
        var panel = new Panel
        {
            Dock = DockStyle.Top,
            Height = 64,
            BackColor = Color.FromArgb(33, 37, 41)
        };

        var welcome = new Label
        {
            Text = $"Welcome {_user.Name} ({_user.Role})",
            AutoSize = true,
            ForeColor = Color.White,
            Font = new Font("Segoe UI", 13, FontStyle.Bold),
            Location = new Point(20, 18)
        };

        var logout = new Button
        {
            Text = "Logout",
            Width = 110,
            Height = 34,
            BackColor = Color.FromArgb(220, 53, 69),
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            Font = new Font("Segoe UI", 9, FontStyle.Bold),
            Anchor = AnchorStyles.Top | AnchorStyles.Right,
            Location = new Point(Width - 170, 14)
        };

        logout.FlatAppearance.BorderSize = 0;
        logout.Click += (_, _) => Close();

        panel.Controls.Add(welcome);
        panel.Controls.Add(logout);

        panel.Resize += (_, _) =>
        {
            logout.Left = panel.Width - logout.Width - 20;
        };

        return panel;
    }

    private void BuildRoleTabs()
    {
        switch (_user.Role)
        {
            case Roles.Donor:
                BuildDonorTabs();
                break;
            case Roles.Receiver:
                BuildReceiverTabs();
                break;
            case Roles.Admin:
                BuildAdminTabs();
                break;
            default:
                ShowWarning("Unsupported role.");
                Close();
                break;
        }
    }

    private static Panel CreateScrollContainer(Control content)
    {
        var panel = new Panel
        {
            Dock = DockStyle.Fill,
            AutoScroll = true
        };

        panel.Controls.Add(content);
        return panel;
    }

    private static TableLayoutPanel CreateFormTable()
    {
        var table = new TableLayoutPanel
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            ColumnCount = 2,
            Padding = new Padding(24),
            Width = 900
        };

        table.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 220));
        table.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));
        return table;
    }

    private static void AddLabeledControl(TableLayoutPanel table, int row, string labelText, Control control)
    {
        table.RowCount = Math.Max(table.RowCount, row + 1);
        table.RowStyles.Add(new RowStyle(SizeType.AutoSize));

        var label = new Label
        {
            Text = labelText,
            AutoSize = true,
            Font = new Font("Segoe UI", 10, FontStyle.Bold),
            Anchor = AnchorStyles.Left,
            Margin = new Padding(0, 7, 8, 7)
        };

        control.Anchor = AnchorStyles.Left;
        table.Controls.Add(label, 0, row);
        table.Controls.Add(control, 1, row);
    }

    private static void AddFullRowControl(TableLayoutPanel table, int row, Control control)
    {
        table.RowCount = Math.Max(table.RowCount, row + 1);
        table.RowStyles.Add(new RowStyle(SizeType.AutoSize));

        control.Anchor = AnchorStyles.Left;
        table.Controls.Add(control, 0, row);
        table.SetColumnSpan(control, 2);
    }

    private static TextBox CreateTextBox(bool multiline = false, int width = 320)
    {
        return new TextBox
        {
            Width = width,
            Font = new Font("Segoe UI", 10),
            Multiline = multiline,
            Height = multiline ? 70 : 32
        };
    }

    private static NumericUpDown CreateNumber(int min, int max, int value)
    {
        return new NumericUpDown
        {
            Minimum = min,
            Maximum = max,
            Value = value,
            Width = 130,
            Font = new Font("Segoe UI", 10)
        };
    }

    private static Button CreatePrimaryButton(string text)
    {
        return CreateButton(text, Color.FromArgb(220, 53, 69));
    }

    private static Button CreateNeutralButton(string text)
    {
        return CreateButton(text, Color.FromArgb(52, 58, 64));
    }

    private static Button CreateDangerButton(string text)
    {
        return CreateButton(text, Color.FromArgb(170, 30, 45));
    }

    private static Button CreateButton(string text, Color color)
    {
        var button = new Button
        {
            Text = text,
            AutoSize = true,
            Padding = new Padding(12, 7, 12, 7),
            Font = new Font("Segoe UI", 9, FontStyle.Bold),
            BackColor = color,
            ForeColor = Color.White,
            FlatStyle = FlatStyle.Flat,
            Margin = new Padding(8, 4, 0, 4)
        };

        button.FlatAppearance.BorderSize = 0;
        return button;
    }

    private static Label CreateInfoLabel(string text)
    {
        return new Label
        {
            Text = text,
            Font = new Font("Segoe UI", 10),
            ForeColor = Color.DimGray,
            AutoSize = true,
            Margin = new Padding(0, 12, 0, 0)
        };
    }

    private static DataGridView CreateReadOnlyGrid()
    {
        return new DataGridView
        {
            ReadOnly = true,
            AllowUserToAddRows = false,
            AllowUserToDeleteRows = false,
            MultiSelect = false,
            SelectionMode = DataGridViewSelectionMode.FullRowSelect,
            AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
            AutoGenerateColumns = true,
            BackgroundColor = Color.White,
            BorderStyle = BorderStyle.FixedSingle,
            Dock = DockStyle.Fill
        };
    }

    private static bool TryGetSelectedId(DataGridView grid, out int id)
    {
        id = 0;
        if (grid.CurrentRow is null || grid.CurrentRow.Cells.Count == 0)
        {
            return false;
        }

        var raw = grid.CurrentRow.Cells[0].Value?.ToString();
        return int.TryParse(raw, out id);
    }

    private static string? NormalizeBlank(string input)
    {
        var text = input.Trim();
        return string.IsNullOrWhiteSpace(text) ? null : text;
    }

    private static bool HasAnyBlank(params string[] values)
    {
        return values.Any(string.IsNullOrWhiteSpace);
    }

    private void RunSafe(Action action)
    {
        try
        {
            action();
        }
        catch (Exception ex)
        {
            ShowError(ex.Message);
        }
    }

    private static void ShowInfo(string message)
    {
        MessageBox.Show(message, "BloodConnect", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private static void ShowWarning(string message)
    {
        MessageBox.Show(message, "BloodConnect", MessageBoxButtons.OK, MessageBoxIcon.Warning);
    }

    private static void ShowError(string message)
    {
        MessageBox.Show(message, "BloodConnect", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
}
