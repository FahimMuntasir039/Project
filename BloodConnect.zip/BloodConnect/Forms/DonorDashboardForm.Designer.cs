namespace BloodConnect.Forms;

partial class DonorDashboardForm
{
    private System.ComponentModel.IContainer components = null;

    private Panel topPanel;
    private Label lblWelcome;
    private Button btnLogout;
    private TabControl tabControl1;
    private TabPage tabProfile;
    private TabPage tabAppointments;
    private TabPage tabHistory;
    private TabPage tabUrgent;
    private Label label1;
    private TextBox txtBloodGroup;
    private Label label2;
    private NumericUpDown nudAge;
    private Label label3;
    private TextBox txtPhone;
    private Label label4;
    private TextBox txtAddress;
    private Label label5;
    private DateTimePicker dtpLastDonation;
    private Button btnSaveProfile;
    private Button btnCheckEligibility;
    private Label lblEligibility;
    private DateTimePicker dtpAppointment;
    private Label label6;
    private Button btnRequestAppointment;
    private Button btnRefreshAppointments;
    private Button btnDeleteAppointment;
    private DataGridView dgvAppointments;
    private Button btnRefreshHistory;
    private DataGridView dgvHistory;
    private Button btnRefreshUrgent;
    private DataGridView dgvUrgent;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        topPanel = new Panel();
        lblWelcome = new Label();
        btnLogout = new Button();
        tabControl1 = new TabControl();
        tabProfile = new TabPage();
        lblEligibility = new Label();
        btnCheckEligibility = new Button();
        btnSaveProfile = new Button();
        dtpLastDonation = new DateTimePicker();
        label5 = new Label();
        txtAddress = new TextBox();
        label4 = new Label();
        txtPhone = new TextBox();
        label3 = new Label();
        nudAge = new NumericUpDown();
        label2 = new Label();
        txtBloodGroup = new TextBox();
        label1 = new Label();
        tabAppointments = new TabPage();
        dgvAppointments = new DataGridView();
        btnDeleteAppointment = new Button();
        btnRefreshAppointments = new Button();
        btnRequestAppointment = new Button();
        label6 = new Label();
        dtpAppointment = new DateTimePicker();
        tabHistory = new TabPage();
        dgvHistory = new DataGridView();
        btnRefreshHistory = new Button();
        tabUrgent = new TabPage();
        dgvUrgent = new DataGridView();
        btnRefreshUrgent = new Button();
        topPanel.SuspendLayout();
        tabControl1.SuspendLayout();
        tabProfile.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)nudAge).BeginInit();
        tabAppointments.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)dgvAppointments).BeginInit();
        tabHistory.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)dgvHistory).BeginInit();
        tabUrgent.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)dgvUrgent).BeginInit();
        SuspendLayout();
        // 
        // topPanel
        // 
        topPanel.BackColor = Color.FromArgb(33, 37, 41);
        topPanel.Controls.Add(lblWelcome);
        topPanel.Controls.Add(btnLogout);
        topPanel.Dock = DockStyle.Top;
        topPanel.Location = new Point(0, 0);
        topPanel.Name = "topPanel";
        topPanel.Size = new Size(1100, 58);
        topPanel.TabIndex = 0;
        // 
        // lblWelcome
        // 
        lblWelcome.AutoSize = true;
        lblWelcome.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
        lblWelcome.ForeColor = Color.White;
        lblWelcome.Location = new Point(16, 18);
        lblWelcome.Name = "lblWelcome";
        lblWelcome.Size = new Size(212, 21);
        lblWelcome.TabIndex = 0;
        lblWelcome.Text = "Welcome Donor Dashboard";
        // 
        // btnLogout
        // 
        btnLogout.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        btnLogout.Location = new Point(1003, 14);
        btnLogout.Name = "btnLogout";
        btnLogout.Size = new Size(80, 30);
        btnLogout.TabIndex = 1;
        btnLogout.Text = "Logout";
        btnLogout.UseVisualStyleBackColor = true;
        btnLogout.Click += btnLogout_Click;
        // 
        // tabControl1
        // 
        tabControl1.Controls.Add(tabProfile);
        tabControl1.Controls.Add(tabAppointments);
        tabControl1.Controls.Add(tabHistory);
        tabControl1.Controls.Add(tabUrgent);
        tabControl1.Dock = DockStyle.Fill;
        tabControl1.Location = new Point(0, 58);
        tabControl1.Name = "tabControl1";
        tabControl1.SelectedIndex = 0;
        tabControl1.Size = new Size(1100, 602);
        tabControl1.TabIndex = 1;
        // 
        // tabProfile
        // 
        tabProfile.Controls.Add(lblEligibility);
        tabProfile.Controls.Add(btnCheckEligibility);
        tabProfile.Controls.Add(btnSaveProfile);
        tabProfile.Controls.Add(dtpLastDonation);
        tabProfile.Controls.Add(label5);
        tabProfile.Controls.Add(txtAddress);
        tabProfile.Controls.Add(label4);
        tabProfile.Controls.Add(txtPhone);
        tabProfile.Controls.Add(label3);
        tabProfile.Controls.Add(nudAge);
        tabProfile.Controls.Add(label2);
        tabProfile.Controls.Add(txtBloodGroup);
        tabProfile.Controls.Add(label1);
        tabProfile.Location = new Point(4, 24);
        tabProfile.Name = "tabProfile";
        tabProfile.Padding = new Padding(3);
        tabProfile.Size = new Size(1092, 574);
        tabProfile.TabIndex = 0;
        tabProfile.Text = "Profile";
        tabProfile.UseVisualStyleBackColor = true;
        // 
        // lblEligibility
        // 
        lblEligibility.AutoSize = true;
        lblEligibility.Location = new Point(38, 375);
        lblEligibility.Name = "lblEligibility";
        lblEligibility.Size = new Size(0, 15);
        lblEligibility.TabIndex = 12;
        // 
        // btnCheckEligibility
        // 
        btnCheckEligibility.Location = new Point(182, 335);
        btnCheckEligibility.Name = "btnCheckEligibility";
        btnCheckEligibility.Size = new Size(130, 28);
        btnCheckEligibility.TabIndex = 11;
        btnCheckEligibility.Text = "Check Eligibility";
        btnCheckEligibility.UseVisualStyleBackColor = true;
        btnCheckEligibility.Click += btnCheckEligibility_Click;
        // 
        // btnSaveProfile
        // 
        btnSaveProfile.Location = new Point(38, 335);
        btnSaveProfile.Name = "btnSaveProfile";
        btnSaveProfile.Size = new Size(130, 28);
        btnSaveProfile.TabIndex = 10;
        btnSaveProfile.Text = "Save Profile";
        btnSaveProfile.UseVisualStyleBackColor = true;
        btnSaveProfile.Click += btnSaveProfile_Click;
        // 
        // dtpLastDonation
        // 
        dtpLastDonation.Checked = false;
        dtpLastDonation.Format = DateTimePickerFormat.Short;
        dtpLastDonation.Location = new Point(38, 296);
        dtpLastDonation.Name = "dtpLastDonation";
        dtpLastDonation.ShowCheckBox = true;
        dtpLastDonation.Size = new Size(200, 23);
        dtpLastDonation.TabIndex = 9;
        // 
        // label5
        // 
        label5.AutoSize = true;
        label5.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        label5.Location = new Point(38, 274);
        label5.Name = "label5";
        label5.Size = new Size(121, 19);
        label5.TabIndex = 8;
        label5.Text = "Last Donation Date";
        // 
        // txtAddress
        // 
        txtAddress.Location = new Point(38, 201);
        txtAddress.Multiline = true;
        txtAddress.Name = "txtAddress";
        txtAddress.Size = new Size(360, 62);
        txtAddress.TabIndex = 7;
        // 
        // label4
        // 
        label4.AutoSize = true;
        label4.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        label4.Location = new Point(38, 179);
        label4.Name = "label4";
        label4.Size = new Size(60, 19);
        label4.TabIndex = 6;
        label4.Text = "Address";
        // 
        // txtPhone
        // 
        txtPhone.Location = new Point(38, 145);
        txtPhone.Name = "txtPhone";
        txtPhone.Size = new Size(200, 23);
        txtPhone.TabIndex = 5;
        // 
        // label3
        // 
        label3.AutoSize = true;
        label3.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        label3.Location = new Point(38, 123);
        label3.Name = "label3";
        label3.Size = new Size(49, 19);
        label3.TabIndex = 4;
        label3.Text = "Phone";
        // 
        // nudAge
        // 
        nudAge.Location = new Point(258, 89);
        nudAge.Maximum = new decimal(new int[] { 120, 0, 0, 0 });
        nudAge.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
        nudAge.Name = "nudAge";
        nudAge.Size = new Size(140, 23);
        nudAge.TabIndex = 3;
        nudAge.Value = new decimal(new int[] { 18, 0, 0, 0 });
        // 
        // label2
        // 
        label2.AutoSize = true;
        label2.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        label2.Location = new Point(258, 67);
        label2.Name = "label2";
        label2.Size = new Size(33, 19);
        label2.TabIndex = 2;
        label2.Text = "Age";
        // 
        // txtBloodGroup
        // 
        txtBloodGroup.Location = new Point(38, 89);
        txtBloodGroup.Name = "txtBloodGroup";
        txtBloodGroup.Size = new Size(200, 23);
        txtBloodGroup.TabIndex = 1;
        // 
        // label1
        // 
        label1.AutoSize = true;
        label1.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        label1.Location = new Point(38, 67);
        label1.Name = "label1";
        label1.Size = new Size(86, 19);
        label1.TabIndex = 0;
        label1.Text = "Blood Group";
        // 
        // tabAppointments
        // 
        tabAppointments.Controls.Add(dgvAppointments);
        tabAppointments.Controls.Add(btnDeleteAppointment);
        tabAppointments.Controls.Add(btnRefreshAppointments);
        tabAppointments.Controls.Add(btnRequestAppointment);
        tabAppointments.Controls.Add(label6);
        tabAppointments.Controls.Add(dtpAppointment);
        tabAppointments.Location = new Point(4, 24);
        tabAppointments.Name = "tabAppointments";
        tabAppointments.Padding = new Padding(3);
        tabAppointments.Size = new Size(1092, 574);
        tabAppointments.TabIndex = 1;
        tabAppointments.Text = "Appointments";
        tabAppointments.UseVisualStyleBackColor = true;
        // 
        // dgvAppointments
        // 
        dgvAppointments.AllowUserToAddRows = false;
        dgvAppointments.AllowUserToDeleteRows = false;
        dgvAppointments.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        dgvAppointments.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        dgvAppointments.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        dgvAppointments.Location = new Point(27, 70);
        dgvAppointments.MultiSelect = false;
        dgvAppointments.Name = "dgvAppointments";
        dgvAppointments.ReadOnly = true;
        dgvAppointments.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        dgvAppointments.Size = new Size(1038, 479);
        dgvAppointments.TabIndex = 5;
        // 
        // btnDeleteAppointment
        // 
        btnDeleteAppointment.Location = new Point(468, 24);
        btnDeleteAppointment.Name = "btnDeleteAppointment";
        btnDeleteAppointment.Size = new Size(160, 28);
        btnDeleteAppointment.TabIndex = 4;
        btnDeleteAppointment.Text = "Delete Selected Pending";
        btnDeleteAppointment.UseVisualStyleBackColor = true;
        btnDeleteAppointment.Click += btnDeleteAppointment_Click;
        // 
        // btnRefreshAppointments
        // 
        btnRefreshAppointments.Location = new Point(367, 24);
        btnRefreshAppointments.Name = "btnRefreshAppointments";
        btnRefreshAppointments.Size = new Size(90, 28);
        btnRefreshAppointments.TabIndex = 3;
        btnRefreshAppointments.Text = "Refresh";
        btnRefreshAppointments.UseVisualStyleBackColor = true;
        btnRefreshAppointments.Click += btnRefreshAppointments_Click;
        // 
        // btnRequestAppointment
        // 
        btnRequestAppointment.Location = new Point(221, 24);
        btnRequestAppointment.Name = "btnRequestAppointment";
        btnRequestAppointment.Size = new Size(140, 28);
        btnRequestAppointment.TabIndex = 2;
        btnRequestAppointment.Text = "Request Appointment";
        btnRequestAppointment.UseVisualStyleBackColor = true;
        btnRequestAppointment.Click += btnRequestAppointment_Click;
        // 
        // label6
        // 
        label6.AutoSize = true;
        label6.Location = new Point(27, 30);
        label6.Name = "label6";
        label6.Size = new Size(101, 15);
        label6.TabIndex = 1;
        label6.Text = "Appointment Date";
        // 
        // dtpAppointment
        // 
        dtpAppointment.Format = DateTimePickerFormat.Short;
        dtpAppointment.Location = new Point(134, 26);
        dtpAppointment.Name = "dtpAppointment";
        dtpAppointment.Size = new Size(80, 23);
        dtpAppointment.TabIndex = 0;
        // 
        // tabHistory
        // 
        tabHistory.Controls.Add(dgvHistory);
        tabHistory.Controls.Add(btnRefreshHistory);
        tabHistory.Location = new Point(4, 24);
        tabHistory.Name = "tabHistory";
        tabHistory.Padding = new Padding(3);
        tabHistory.Size = new Size(1092, 574);
        tabHistory.TabIndex = 2;
        tabHistory.Text = "Donation History";
        tabHistory.UseVisualStyleBackColor = true;
        // 
        // dgvHistory
        // 
        dgvHistory.AllowUserToAddRows = false;
        dgvHistory.AllowUserToDeleteRows = false;
        dgvHistory.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        dgvHistory.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        dgvHistory.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        dgvHistory.Location = new Point(27, 56);
        dgvHistory.MultiSelect = false;
        dgvHistory.Name = "dgvHistory";
        dgvHistory.ReadOnly = true;
        dgvHistory.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        dgvHistory.Size = new Size(1038, 493);
        dgvHistory.TabIndex = 1;
        // 
        // btnRefreshHistory
        // 
        btnRefreshHistory.Location = new Point(27, 21);
        btnRefreshHistory.Name = "btnRefreshHistory";
        btnRefreshHistory.Size = new Size(125, 28);
        btnRefreshHistory.TabIndex = 0;
        btnRefreshHistory.Text = "Refresh History";
        btnRefreshHistory.UseVisualStyleBackColor = true;
        btnRefreshHistory.Click += btnRefreshHistory_Click;
        // 
        // tabUrgent
        // 
        tabUrgent.Controls.Add(dgvUrgent);
        tabUrgent.Controls.Add(btnRefreshUrgent);
        tabUrgent.Location = new Point(4, 24);
        tabUrgent.Name = "tabUrgent";
        tabUrgent.Padding = new Padding(3);
        tabUrgent.Size = new Size(1092, 574);
        tabUrgent.TabIndex = 3;
        tabUrgent.Text = "Urgent Needs";
        tabUrgent.UseVisualStyleBackColor = true;
        // 
        // dgvUrgent
        // 
        dgvUrgent.AllowUserToAddRows = false;
        dgvUrgent.AllowUserToDeleteRows = false;
        dgvUrgent.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        dgvUrgent.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        dgvUrgent.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        dgvUrgent.Location = new Point(27, 56);
        dgvUrgent.MultiSelect = false;
        dgvUrgent.Name = "dgvUrgent";
        dgvUrgent.ReadOnly = true;
        dgvUrgent.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        dgvUrgent.Size = new Size(1038, 493);
        dgvUrgent.TabIndex = 1;
        // 
        // btnRefreshUrgent
        // 
        btnRefreshUrgent.Location = new Point(27, 21);
        btnRefreshUrgent.Name = "btnRefreshUrgent";
        btnRefreshUrgent.Size = new Size(164, 28);
        btnRefreshUrgent.TabIndex = 0;
        btnRefreshUrgent.Text = "Refresh Urgent Requests";
        btnRefreshUrgent.UseVisualStyleBackColor = true;
        btnRefreshUrgent.Click += btnRefreshUrgent_Click;
        // 
        // DonorDashboardForm
        // 
        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(1100, 660);
        Controls.Add(tabControl1);
        Controls.Add(topPanel);
        Name = "DonorDashboardForm";
        StartPosition = FormStartPosition.CenterParent;
        Text = "Donor Dashboard";
        Load += DonorDashboardForm_Load;
        topPanel.ResumeLayout(false);
        topPanel.PerformLayout();
        tabControl1.ResumeLayout(false);
        tabProfile.ResumeLayout(false);
        tabProfile.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)nudAge).EndInit();
        tabAppointments.ResumeLayout(false);
        tabAppointments.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)dgvAppointments).EndInit();
        tabHistory.ResumeLayout(false);
        ((System.ComponentModel.ISupportInitialize)dgvHistory).EndInit();
        tabUrgent.ResumeLayout(false);
        ((System.ComponentModel.ISupportInitialize)dgvUrgent).EndInit();
        ResumeLayout(false);
    }
}
