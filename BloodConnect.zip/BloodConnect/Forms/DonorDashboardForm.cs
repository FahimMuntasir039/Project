using BloodConnect.Models;
using BloodConnect.Services;

namespace BloodConnect.Forms;

public partial class DonorDashboardForm : Form
{
    private readonly User _user;
    private DonorService? _donorService;

    public DonorDashboardForm()
    {
        InitializeComponent();
        _user = new User();
    }

    public DonorDashboardForm(User user, DonorService donorService) : this()
    {
        _user = user;
        _donorService = donorService;
        lblWelcome.Text = $"Welcome {_user.Name} (Donor)";
    }

    private void DonorDashboardForm_Load(object sender, EventArgs e)
    {
        if (_donorService is null)
        {
            return;
        }

        LoadProfile();
        RefreshAppointments();
        RefreshHistory();
        RefreshUrgent();
    }

    private bool Ready()
    {
        if (_donorService is not null)
        {
            return true;
        }

        MessageBox.Show("Donor service is not initialized.", "BloodConnect", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        return false;
    }

    private Donor? GetCurrentDonor()
    {
        return _donorService?.GetDonorByUserId(_user.UserId);
    }

    private void LoadProfile()
    {
        var donor = GetCurrentDonor();
        if (donor is null)
        {
            return;
        }

        txtBloodGroup.Text = donor.BloodGroup;
        nudAge.Value = donor.Age;
        txtPhone.Text = donor.Phone;
        txtAddress.Text = donor.Address;

        if (donor.LastDonationDate.HasValue)
        {
            dtpLastDonation.Checked = true;
            dtpLastDonation.Value = donor.LastDonationDate.Value;
        }
        else
        {
            dtpLastDonation.Checked = false;
        }
    }

    private void btnSaveProfile_Click(object sender, EventArgs e)
    {
        if (!Ready())
        {
            return;
        }

        if (string.IsNullOrWhiteSpace(txtBloodGroup.Text) || string.IsNullOrWhiteSpace(txtPhone.Text) || string.IsNullOrWhiteSpace(txtAddress.Text))
        {
            MessageBox.Show("Please fill profile fields.", "BloodConnect", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        var saved = _donorService!.UpsertDonorProfile(
            _user.UserId,
            txtBloodGroup.Text.Trim(),
            Convert.ToInt32(nudAge.Value),
            txtPhone.Text.Trim(),
            txtAddress.Text.Trim(),
            dtpLastDonation.Checked ? dtpLastDonation.Value.Date : null);

        MessageBox.Show(saved ? "Profile saved." : "Could not save profile.", "BloodConnect", MessageBoxButtons.OK, saved ? MessageBoxIcon.Information : MessageBoxIcon.Error);
    }

    private void btnCheckEligibility_Click(object sender, EventArgs e)
    {
        if (!Ready())
        {
            return;
        }

        var donor = GetCurrentDonor();
        if (donor is null)
        {
            lblEligibility.Text = "Profile not found. Save profile first.";
            return;
        }

        var eligibility = _donorService!.CheckEligibility(donor.DonorId);
        lblEligibility.Text = $"Eligible: {(eligibility.IsEligible ? "Yes" : "No")} | {eligibility.Reason}";
    }

    private void btnRequestAppointment_Click(object sender, EventArgs e)
    {
        if (!Ready())
        {
            return;
        }

        var donor = GetCurrentDonor();
        if (donor is null)
        {
            MessageBox.Show("Profile not found. Save profile first.", "BloodConnect", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        var requested = _donorService!.RequestAppointment(donor.DonorId, dtpAppointment.Value.Date);
        MessageBox.Show(requested ? "Appointment requested." : "Could not request appointment.", "BloodConnect", MessageBoxButtons.OK, requested ? MessageBoxIcon.Information : MessageBoxIcon.Error);
        RefreshAppointments();
    }

    private void btnRefreshAppointments_Click(object sender, EventArgs e)
    {
        if (Ready())
        {
            RefreshAppointments();
        }
    }

    private void btnDeleteAppointment_Click(object sender, EventArgs e)
    {
        if (!Ready())
        {
            return;
        }

        var donor = GetCurrentDonor();
        if (donor is null)
        {
            return;
        }

        if (!TryGetSelectedId(dgvAppointments, out var appointmentId))
        {
            MessageBox.Show("Select appointment row first.", "BloodConnect", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        var deleted = _donorService!.DeletePendingAppointment(donor.DonorId, appointmentId);
        MessageBox.Show(deleted ? "Pending appointment deleted." : "Could not delete appointment.", "BloodConnect", MessageBoxButtons.OK, deleted ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
        RefreshAppointments();
    }

    private void RefreshAppointments()
    {
        var donor = GetCurrentDonor();
        if (donor is null)
        {
            dgvAppointments.DataSource = null;
            return;
        }

        var list = _donorService!.GetAppointments(donor.DonorId)
            .Select(x => new
            {
                Id = x.AppointmentId,
                Date = x.AppointmentDate.ToString("yyyy-MM-dd"),
                x.Status,
                CreatedAt = x.CreatedAt.ToString("yyyy-MM-dd HH:mm")
            })
            .ToList();

        dgvAppointments.DataSource = list;
    }

    private void btnRefreshHistory_Click(object sender, EventArgs e)
    {
        if (Ready())
        {
            RefreshHistory();
        }
    }

    private void RefreshHistory()
    {
        var donor = GetCurrentDonor();
        if (donor is null)
        {
            dgvHistory.DataSource = null;
            return;
        }

        var list = _donorService!.GetDonationHistory(donor.DonorId)
            .Select(x => new
            {
                Id = x.HistoryId,
                Date = x.DonationDate.ToString("yyyy-MM-dd"),
                x.BloodGroup,
                x.Quantity
            })
            .ToList();

        dgvHistory.DataSource = list;
    }

    private void btnRefreshUrgent_Click(object sender, EventArgs e)
    {
        if (Ready())
        {
            RefreshUrgent();
        }
    }

    private void RefreshUrgent()
    {
        var list = _donorService!.GetUrgentRequests()
            .Select(x => new
            {
                Id = x.RequestId,
                x.BloodGroup,
                x.Quantity,
                x.Status,
                Date = x.RequestDate.ToString("yyyy-MM-dd HH:mm")
            })
            .ToList();

        dgvUrgent.DataSource = list;
    }

    private static bool TryGetSelectedId(DataGridView grid, out int id)
    {
        id = 0;
        if (grid.CurrentRow is null || grid.CurrentRow.Cells.Count == 0)
        {
            return false;
        }

        return int.TryParse(grid.CurrentRow.Cells[0].Value?.ToString(), out id);
    }

    private void btnLogout_Click(object sender, EventArgs e)
    {
        Close();
    }
}
