namespace BloodConnect.Forms;

partial class LoginForm
{
    private System.ComponentModel.IContainer components = null;

    private Label lblTitle;
    private Label lblSubtitle;
    private Label lblEmail;
    private Label lblPassword;
    private TextBox txtEmail;
    private TextBox txtPassword;
    private Button btnLogin;
    private LinkLabel lnkCreateAccount;
    private Label lblAdminHint;
    private Panel cardPanel;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        lblTitle = new Label();
        lblSubtitle = new Label();
        lblEmail = new Label();
        lblPassword = new Label();
        txtEmail = new TextBox();
        txtPassword = new TextBox();
        btnLogin = new Button();
        lnkCreateAccount = new LinkLabel();
        lblAdminHint = new Label();
        cardPanel = new Panel();
        cardPanel.SuspendLayout();
        SuspendLayout();
        // 
        // lblTitle
        // 
        lblTitle.AutoSize = true;
        lblTitle.Font = new Font("Segoe UI", 20F, FontStyle.Bold);
        lblTitle.ForeColor = Color.FromArgb(220, 53, 69);
        lblTitle.Location = new Point(24, 22);
        lblTitle.Name = "lblTitle";
        lblTitle.Size = new Size(198, 37);
        lblTitle.TabIndex = 0;
        lblTitle.Text = "BloodConnect";
        // 
        // lblSubtitle
        // 
        lblSubtitle.AutoSize = true;
        lblSubtitle.Font = new Font("Segoe UI", 10F);
        lblSubtitle.ForeColor = Color.DimGray;
        lblSubtitle.Location = new Point(27, 64);
        lblSubtitle.Name = "lblSubtitle";
        lblSubtitle.Size = new Size(117, 19);
        lblSubtitle.TabIndex = 1;
        lblSubtitle.Text = "Login to continue";
        // 
        // lblEmail
        // 
        lblEmail.AutoSize = true;
        lblEmail.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        lblEmail.Location = new Point(30, 108);
        lblEmail.Name = "lblEmail";
        lblEmail.Size = new Size(45, 19);
        lblEmail.TabIndex = 2;
        lblEmail.Text = "Email";
        // 
        // lblPassword
        // 
        lblPassword.AutoSize = true;
        lblPassword.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        lblPassword.Location = new Point(30, 170);
        lblPassword.Name = "lblPassword";
        lblPassword.Size = new Size(73, 19);
        lblPassword.TabIndex = 4;
        lblPassword.Text = "Password";
        // 
        // txtEmail
        // 
        txtEmail.Font = new Font("Segoe UI", 10F);
        txtEmail.Location = new Point(30, 131);
        txtEmail.Name = "txtEmail";
        txtEmail.Size = new Size(438, 25);
        txtEmail.TabIndex = 3;
        // 
        // txtPassword
        // 
        txtPassword.Font = new Font("Segoe UI", 10F);
        txtPassword.Location = new Point(30, 193);
        txtPassword.Name = "txtPassword";
        txtPassword.Size = new Size(438, 25);
        txtPassword.TabIndex = 5;
        txtPassword.UseSystemPasswordChar = true;
        // 
        // btnLogin
        // 
        btnLogin.BackColor = Color.FromArgb(220, 53, 69);
        btnLogin.FlatAppearance.BorderSize = 0;
        btnLogin.FlatStyle = FlatStyle.Flat;
        btnLogin.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        btnLogin.ForeColor = Color.White;
        btnLogin.Location = new Point(30, 238);
        btnLogin.Name = "btnLogin";
        btnLogin.Size = new Size(438, 34);
        btnLogin.TabIndex = 6;
        btnLogin.Text = "Login";
        btnLogin.UseVisualStyleBackColor = false;
        btnLogin.Click += btnLogin_Click;
        // 
        // lnkCreateAccount
        // 
        lnkCreateAccount.AutoSize = true;
        lnkCreateAccount.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        lnkCreateAccount.LinkColor = Color.FromArgb(220, 53, 69);
        lnkCreateAccount.Location = new Point(30, 286);
        lnkCreateAccount.Name = "lnkCreateAccount";
        lnkCreateAccount.Size = new Size(64, 19);
        lnkCreateAccount.TabIndex = 7;
        lnkCreateAccount.TabStop = true;
        lnkCreateAccount.Text = "Register";
        lnkCreateAccount.LinkClicked += lnkCreateAccount_LinkClicked;
        // 
        // lblAdminHint
        // 
        lblAdminHint.AutoSize = true;
        lblAdminHint.Font = new Font("Segoe UI", 9F);
        lblAdminHint.ForeColor = Color.DimGray;
        lblAdminHint.Location = new Point(30, 317);
        lblAdminHint.Name = "lblAdminHint";
        lblAdminHint.Size = new Size(297, 15);
        lblAdminHint.TabIndex = 8;
        lblAdminHint.Text = "Default admin: admin@bloodconnect.com / admin123";
        // 
        // cardPanel
        // 
        cardPanel.Anchor = AnchorStyles.None;
        cardPanel.BackColor = Color.White;
        cardPanel.BorderStyle = BorderStyle.FixedSingle;
        cardPanel.Controls.Add(lblTitle);
        cardPanel.Controls.Add(lblSubtitle);
        cardPanel.Controls.Add(lblEmail);
        cardPanel.Controls.Add(txtEmail);
        cardPanel.Controls.Add(lblPassword);
        cardPanel.Controls.Add(txtPassword);
        cardPanel.Controls.Add(btnLogin);
        cardPanel.Controls.Add(lnkCreateAccount);
        cardPanel.Controls.Add(lblAdminHint);
        cardPanel.Location = new Point(130, 60);
        cardPanel.Name = "cardPanel";
        cardPanel.Size = new Size(500, 360);
        cardPanel.TabIndex = 0;
        cardPanel.Paint += cardPanel_Paint;
        // 
        // LoginForm
        // 
        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        BackColor = Color.FromArgb(245, 247, 250);
        ClientSize = new Size(760, 480);
        Controls.Add(cardPanel);
        Name = "LoginForm";
        StartPosition = FormStartPosition.CenterScreen;
        Text = "BloodConnect - Login";
        cardPanel.ResumeLayout(false);
        cardPanel.PerformLayout();
        ResumeLayout(false);
    }
}
