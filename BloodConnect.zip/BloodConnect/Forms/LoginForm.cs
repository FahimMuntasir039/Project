using BloodConnect.Models;
using BloodConnect.Services;

namespace BloodConnect.Forms;

public partial class LoginForm : Form
{
    private AuthService? _authService;
    private DonorService? _donorService;
    private ReceiverService? _receiverService;
    private AdminService? _adminService;

    public LoginForm()
    {
        InitializeComponent();
    }

    public LoginForm(
        AuthService authService,
        DonorService donorService,
        ReceiverService receiverService,
        AdminService adminService) : this()
    {
        _authService = authService;
        _donorService = donorService;
        _receiverService = receiverService;
        _adminService = adminService;
    }

    private bool ServicesReady()
    {
        if (_authService is not null && _donorService is not null && _receiverService is not null && _adminService is not null)
        {
            return true;
        }

        MessageBox.Show(
            "Services are not initialized. Start the app from Program.cs.",
            "BloodConnect",
            MessageBoxButtons.OK,
            MessageBoxIcon.Warning);

        return false;
    }

    private void btnLogin_Click(object sender, EventArgs e)
    {
        if (!ServicesReady())
        {
            return;
        }

        var email = txtEmail.Text.Trim();
        var password = txtPassword.Text;

        if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
        {
            MessageBox.Show("Please enter email and password.", "BloodConnect", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        var user = _authService!.Login(email, password);
        if (user is null)
        {
            MessageBox.Show("Invalid email or password.", "BloodConnect", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        Form dashboard = user.Role switch
        {
            Roles.Donor => new DonorDashboardForm(user, _donorService!),
            Roles.Receiver => new ReceiverDashboardForm(user, _receiverService!),
            Roles.Admin => new AdminDashboardForm(_adminService!),
            _ => throw new InvalidOperationException("Unsupported role.")
        };

        using (dashboard)
        {
            Hide();
            dashboard.ShowDialog(this);
            Show();
        }

        txtPassword.Clear();
    }

    private void lnkCreateAccount_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
    {
        if (!ServicesReady())
        {
            return;
        }

        using var createForm = new CreateAccountForm(_authService!, _donorService!, _receiverService!);
        if (createForm.ShowDialog(this) != DialogResult.OK)
        {
            return;
        }

        txtEmail.Text = createForm.CreatedEmail;
        txtPassword.Clear();
        txtPassword.Focus();

        MessageBox.Show("Account created. Please login.", "BloodConnect", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    private void cardPanel_Paint(object sender, PaintEventArgs e)
    {

    }
}
