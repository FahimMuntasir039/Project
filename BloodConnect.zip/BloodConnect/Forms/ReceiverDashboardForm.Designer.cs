namespace BloodConnect.Forms;

partial class ReceiverDashboardForm
{
    private System.ComponentModel.IContainer components = null;

    private Panel topPanel;
    private Label lblWelcome;
    private Button btnLogout;
    private TabControl tabControl1;
    private TabPage tabProfile;
    private TabPage tabSearch;
    private TabPage tabRequests;
    private TabPage tabHospitals;
    private Label label1;
    private TextBox txtBloodGroupNeeded;
    private Label label2;
    private TextBox txtPhone;
    private Label label3;
    private TextBox txtAddress;
    private Button btnSaveProfile;
    private Label label4;
    private TextBox txtSearchGroup;
    private Label label5;
    private TextBox txtSearchLocation;
    private Button btnSearchStock;
    private DataGridView dgvStock;
    private Label label6;
    private TextBox txtRequestGroup;
    private Label label7;
    private NumericUpDown nudQuantity;
    private Button btnSendRequest;
    private Button btnRefreshRequests;
    private Button btnDeleteRequest;
    private DataGridView dgvRequests;
    private Button btnRefreshHospitals;
    private ListBox lstHospitals;

    protected override void Dispose(bool disposing)
    {
        if (disposing && (components != null))
        {
            components.Dispose();
        }

        base.Dispose(disposing);
    }

    private void InitializeComponent()
    {
        topPanel = new Panel();
        lblWelcome = new Label();
        btnLogout = new Button();
        tabControl1 = new TabControl();
        tabProfile = new TabPage();
        btnSaveProfile = new Button();
        txtAddress = new TextBox();
        label3 = new Label();
        txtPhone = new TextBox();
        label2 = new Label();
        txtBloodGroupNeeded = new TextBox();
        label1 = new Label();
        tabSearch = new TabPage();
        dgvStock = new DataGridView();
        btnSearchStock = new Button();
        txtSearchLocation = new TextBox();
        label5 = new Label();
        txtSearchGroup = new TextBox();
        label4 = new Label();
        tabRequests = new TabPage();
        dgvRequests = new DataGridView();
        btnDeleteRequest = new Button();
        btnRefreshRequests = new Button();
        btnSendRequest = new Button();
        nudQuantity = new NumericUpDown();
        label7 = new Label();
        txtRequestGroup = new TextBox();
        label6 = new Label();
        tabHospitals = new TabPage();
        lstHospitals = new ListBox();
        btnRefreshHospitals = new Button();
        topPanel.SuspendLayout();
        tabControl1.SuspendLayout();
        tabProfile.SuspendLayout();
        tabSearch.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)dgvStock).BeginInit();
        tabRequests.SuspendLayout();
        ((System.ComponentModel.ISupportInitialize)dgvRequests).BeginInit();
        ((System.ComponentModel.ISupportInitialize)nudQuantity).BeginInit();
        tabHospitals.SuspendLayout();
        SuspendLayout();
        // 
        // topPanel
        // 
        topPanel.BackColor = Color.FromArgb(33, 37, 41);
        topPanel.Controls.Add(lblWelcome);
        topPanel.Controls.Add(btnLogout);
        topPanel.Dock = DockStyle.Top;
        topPanel.Location = new Point(0, 0);
        topPanel.Name = "topPanel";
        topPanel.Size = new Size(1100, 58);
        topPanel.TabIndex = 0;
        // 
        // lblWelcome
        // 
        lblWelcome.AutoSize = true;
        lblWelcome.Font = new Font("Segoe UI", 12F, FontStyle.Bold);
        lblWelcome.ForeColor = Color.White;
        lblWelcome.Location = new Point(16, 18);
        lblWelcome.Name = "lblWelcome";
        lblWelcome.Size = new Size(229, 21);
        lblWelcome.TabIndex = 0;
        lblWelcome.Text = "Welcome Receiver Dashboard";
        // 
        // btnLogout
        // 
        btnLogout.Anchor = AnchorStyles.Top | AnchorStyles.Right;
        btnLogout.Location = new Point(1003, 14);
        btnLogout.Name = "btnLogout";
        btnLogout.Size = new Size(80, 30);
        btnLogout.TabIndex = 1;
        btnLogout.Text = "Logout";
        btnLogout.UseVisualStyleBackColor = true;
        btnLogout.Click += btnLogout_Click;
        // 
        // tabControl1
        // 
        tabControl1.Controls.Add(tabProfile);
        tabControl1.Controls.Add(tabSearch);
        tabControl1.Controls.Add(tabRequests);
        tabControl1.Controls.Add(tabHospitals);
        tabControl1.Dock = DockStyle.Fill;
        tabControl1.Location = new Point(0, 58);
        tabControl1.Name = "tabControl1";
        tabControl1.SelectedIndex = 0;
        tabControl1.Size = new Size(1100, 602);
        tabControl1.TabIndex = 1;
        // 
        // tabProfile
        // 
        tabProfile.Controls.Add(btnSaveProfile);
        tabProfile.Controls.Add(txtAddress);
        tabProfile.Controls.Add(label3);
        tabProfile.Controls.Add(txtPhone);
        tabProfile.Controls.Add(label2);
        tabProfile.Controls.Add(txtBloodGroupNeeded);
        tabProfile.Controls.Add(label1);
        tabProfile.Location = new Point(4, 24);
        tabProfile.Name = "tabProfile";
        tabProfile.Padding = new Padding(3);
        tabProfile.Size = new Size(1092, 574);
        tabProfile.TabIndex = 0;
        tabProfile.Text = "Profile";
        tabProfile.UseVisualStyleBackColor = true;
        // 
        // btnSaveProfile
        // 
        btnSaveProfile.Location = new Point(33, 288);
        btnSaveProfile.Name = "btnSaveProfile";
        btnSaveProfile.Size = new Size(130, 28);
        btnSaveProfile.TabIndex = 6;
        btnSaveProfile.Text = "Save Profile";
        btnSaveProfile.UseVisualStyleBackColor = true;
        btnSaveProfile.Click += btnSaveProfile_Click;
        // 
        // txtAddress
        // 
        txtAddress.Location = new Point(33, 150);
        txtAddress.Multiline = true;
        txtAddress.Name = "txtAddress";
        txtAddress.Size = new Size(360, 120);
        txtAddress.TabIndex = 5;
        // 
        // label3
        // 
        label3.AutoSize = true;
        label3.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        label3.Location = new Point(33, 128);
        label3.Name = "label3";
        label3.Size = new Size(60, 19);
        label3.TabIndex = 4;
        label3.Text = "Address";
        // 
        // txtPhone
        // 
        txtPhone.Location = new Point(33, 94);
        txtPhone.Name = "txtPhone";
        txtPhone.Size = new Size(240, 23);
        txtPhone.TabIndex = 3;
        // 
        // label2
        // 
        label2.AutoSize = true;
        label2.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        label2.Location = new Point(33, 72);
        label2.Name = "label2";
        label2.Size = new Size(49, 19);
        label2.TabIndex = 2;
        label2.Text = "Phone";
        // 
        // txtBloodGroupNeeded
        // 
        txtBloodGroupNeeded.Location = new Point(33, 38);
        txtBloodGroupNeeded.Name = "txtBloodGroupNeeded";
        txtBloodGroupNeeded.Size = new Size(240, 23);
        txtBloodGroupNeeded.TabIndex = 1;
        // 
        // label1
        // 
        label1.AutoSize = true;
        label1.Font = new Font("Segoe UI", 10F, FontStyle.Bold);
        label1.Location = new Point(33, 16);
        label1.Name = "label1";
        label1.Size = new Size(142, 19);
        label1.TabIndex = 0;
        label1.Text = "Blood Group Needed";
        // 
        // tabSearch
        // 
        tabSearch.Controls.Add(dgvStock);
        tabSearch.Controls.Add(btnSearchStock);
        tabSearch.Controls.Add(txtSearchLocation);
        tabSearch.Controls.Add(label5);
        tabSearch.Controls.Add(txtSearchGroup);
        tabSearch.Controls.Add(label4);
        tabSearch.Location = new Point(4, 24);
        tabSearch.Name = "tabSearch";
        tabSearch.Padding = new Padding(3);
        tabSearch.Size = new Size(1092, 574);
        tabSearch.TabIndex = 1;
        tabSearch.Text = "Search Stock";
        tabSearch.UseVisualStyleBackColor = true;
        // 
        // dgvStock
        // 
        dgvStock.AllowUserToAddRows = false;
        dgvStock.AllowUserToDeleteRows = false;
        dgvStock.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        dgvStock.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        dgvStock.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        dgvStock.Location = new Point(28, 79);
        dgvStock.MultiSelect = false;
        dgvStock.Name = "dgvStock";
        dgvStock.ReadOnly = true;
        dgvStock.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        dgvStock.Size = new Size(1036, 470);
        dgvStock.TabIndex = 5;
        // 
        // btnSearchStock
        // 
        btnSearchStock.Location = new Point(531, 28);
        btnSearchStock.Name = "btnSearchStock";
        btnSearchStock.Size = new Size(92, 28);
        btnSearchStock.TabIndex = 4;
        btnSearchStock.Text = "Search";
        btnSearchStock.UseVisualStyleBackColor = true;
        btnSearchStock.Click += btnSearchStock_Click;
        // 
        // txtSearchLocation
        // 
        txtSearchLocation.Location = new Point(327, 31);
        txtSearchLocation.Name = "txtSearchLocation";
        txtSearchLocation.Size = new Size(180, 23);
        txtSearchLocation.TabIndex = 3;
        // 
        // label5
        // 
        label5.AutoSize = true;
        label5.Location = new Point(227, 34);
        label5.Name = "label5";
        label5.Size = new Size(94, 15);
        label5.TabIndex = 2;
        label5.Text = "Location/Hospital";
        // 
        // txtSearchGroup
        // 
        txtSearchGroup.Location = new Point(121, 31);
        txtSearchGroup.Name = "txtSearchGroup";
        txtSearchGroup.Size = new Size(90, 23);
        txtSearchGroup.TabIndex = 1;
        // 
        // label4
        // 
        label4.AutoSize = true;
        label4.Location = new Point(28, 34);
        label4.Name = "label4";
        label4.Size = new Size(75, 15);
        label4.TabIndex = 0;
        label4.Text = "Blood Group";
        // 
        // tabRequests
        // 
        tabRequests.Controls.Add(dgvRequests);
        tabRequests.Controls.Add(btnDeleteRequest);
        tabRequests.Controls.Add(btnRefreshRequests);
        tabRequests.Controls.Add(btnSendRequest);
        tabRequests.Controls.Add(nudQuantity);
        tabRequests.Controls.Add(label7);
        tabRequests.Controls.Add(txtRequestGroup);
        tabRequests.Controls.Add(label6);
        tabRequests.Location = new Point(4, 24);
        tabRequests.Name = "tabRequests";
        tabRequests.Padding = new Padding(3);
        tabRequests.Size = new Size(1092, 574);
        tabRequests.TabIndex = 2;
        tabRequests.Text = "Requests";
        tabRequests.UseVisualStyleBackColor = true;
        // 
        // dgvRequests
        // 
        dgvRequests.AllowUserToAddRows = false;
        dgvRequests.AllowUserToDeleteRows = false;
        dgvRequests.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        dgvRequests.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
        dgvRequests.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
        dgvRequests.Location = new Point(28, 79);
        dgvRequests.MultiSelect = false;
        dgvRequests.Name = "dgvRequests";
        dgvRequests.ReadOnly = true;
        dgvRequests.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
        dgvRequests.Size = new Size(1036, 470);
        dgvRequests.TabIndex = 7;
        // 
        // btnDeleteRequest
        // 
        btnDeleteRequest.Location = new Point(590, 27);
        btnDeleteRequest.Name = "btnDeleteRequest";
        btnDeleteRequest.Size = new Size(170, 28);
        btnDeleteRequest.TabIndex = 6;
        btnDeleteRequest.Text = "Delete Selected Pending";
        btnDeleteRequest.UseVisualStyleBackColor = true;
        btnDeleteRequest.Click += btnDeleteRequest_Click;
        // 
        // btnRefreshRequests
        // 
        btnRefreshRequests.Location = new Point(492, 27);
        btnRefreshRequests.Name = "btnRefreshRequests";
        btnRefreshRequests.Size = new Size(90, 28);
        btnRefreshRequests.TabIndex = 5;
        btnRefreshRequests.Text = "Refresh";
        btnRefreshRequests.UseVisualStyleBackColor = true;
        btnRefreshRequests.Click += btnRefreshRequests_Click;
        // 
        // btnSendRequest
        // 
        btnSendRequest.Location = new Point(375, 27);
        btnSendRequest.Name = "btnSendRequest";
        btnSendRequest.Size = new Size(110, 28);
        btnSendRequest.TabIndex = 4;
        btnSendRequest.Text = "Send Request";
        btnSendRequest.UseVisualStyleBackColor = true;
        btnSendRequest.Click += btnSendRequest_Click;
        // 
        // nudQuantity
        // 
        nudQuantity.Location = new Point(282, 30);
        nudQuantity.Minimum = new decimal(new int[] { 1, 0, 0, 0 });
        nudQuantity.Name = "nudQuantity";
        nudQuantity.Size = new Size(70, 23);
        nudQuantity.TabIndex = 3;
        nudQuantity.Value = new decimal(new int[] { 1, 0, 0, 0 });
        // 
        // label7
        // 
        label7.AutoSize = true;
        label7.Location = new Point(227, 32);
        label7.Name = "label7";
        label7.Size = new Size(53, 15);
        label7.TabIndex = 2;
        label7.Text = "Quantity";
        // 
        // txtRequestGroup
        // 
        txtRequestGroup.Location = new Point(121, 29);
        txtRequestGroup.Name = "txtRequestGroup";
        txtRequestGroup.Size = new Size(90, 23);
        txtRequestGroup.TabIndex = 1;
        // 
        // label6
        // 
        label6.AutoSize = true;
        label6.Location = new Point(28, 32);
        label6.Name = "label6";
        label6.Size = new Size(75, 15);
        label6.TabIndex = 0;
        label6.Text = "Blood Group";
        // 
        // tabHospitals
        // 
        tabHospitals.Controls.Add(lstHospitals);
        tabHospitals.Controls.Add(btnRefreshHospitals);
        tabHospitals.Location = new Point(4, 24);
        tabHospitals.Name = "tabHospitals";
        tabHospitals.Padding = new Padding(3);
        tabHospitals.Size = new Size(1092, 574);
        tabHospitals.TabIndex = 3;
        tabHospitals.Text = "Hospitals";
        tabHospitals.UseVisualStyleBackColor = true;
        // 
        // lstHospitals
        // 
        lstHospitals.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
        lstHospitals.Font = new Font("Segoe UI", 11F);
        lstHospitals.FormattingEnabled = true;
        lstHospitals.ItemHeight = 20;
        lstHospitals.Location = new Point(28, 62);
        lstHospitals.Name = "lstHospitals";
        lstHospitals.Size = new Size(1036, 484);
        lstHospitals.TabIndex = 1;
        // 
        // btnRefreshHospitals
        // 
        btnRefreshHospitals.Location = new Point(28, 21);
        btnRefreshHospitals.Name = "btnRefreshHospitals";
        btnRefreshHospitals.Size = new Size(130, 28);
        btnRefreshHospitals.TabIndex = 0;
        btnRefreshHospitals.Text = "Refresh Hospitals";
        btnRefreshHospitals.UseVisualStyleBackColor = true;
        btnRefreshHospitals.Click += btnRefreshHospitals_Click;
        // 
        // ReceiverDashboardForm
        // 
        AutoScaleDimensions = new SizeF(7F, 15F);
        AutoScaleMode = AutoScaleMode.Font;
        ClientSize = new Size(1100, 660);
        Controls.Add(tabControl1);
        Controls.Add(topPanel);
        Name = "ReceiverDashboardForm";
        StartPosition = FormStartPosition.CenterParent;
        Text = "Receiver Dashboard";
        Load += ReceiverDashboardForm_Load;
        topPanel.ResumeLayout(false);
        topPanel.PerformLayout();
        tabControl1.ResumeLayout(false);
        tabProfile.ResumeLayout(false);
        tabProfile.PerformLayout();
        tabSearch.ResumeLayout(false);
        tabSearch.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)dgvStock).EndInit();
        tabRequests.ResumeLayout(false);
        tabRequests.PerformLayout();
        ((System.ComponentModel.ISupportInitialize)dgvRequests).EndInit();
        ((System.ComponentModel.ISupportInitialize)nudQuantity).EndInit();
        tabHospitals.ResumeLayout(false);
        ResumeLayout(false);
    }
}
