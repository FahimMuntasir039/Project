using BloodConnect.Models;
using BloodConnect.Services;

namespace BloodConnect.Forms;

public partial class ReceiverDashboardForm : Form
{
    private readonly User _user;
    private ReceiverService? _receiverService;

    public ReceiverDashboardForm()
    {
        InitializeComponent();
        _user = new User();
    }

    public ReceiverDashboardForm(User user, ReceiverService receiverService) : this()
    {
        _user = user;
        _receiverService = receiverService;
        lblWelcome.Text = $"Welcome {_user.Name} (Receiver)";
    }

    private void ReceiverDashboardForm_Load(object sender, EventArgs e)
    {
        if (_receiverService is null)
        {
            return;
        }

        LoadProfile();
        RefreshRequests();
        RefreshHospitals();
    }

    private bool Ready()
    {
        if (_receiverService is not null)
        {
            return true;
        }

        MessageBox.Show("Receiver service is not initialized.", "BloodConnect", MessageBoxButtons.OK, MessageBoxIcon.Warning);
        return false;
    }

    private Receiver? GetCurrentReceiver()
    {
        return _receiverService?.GetReceiverByUserId(_user.UserId);
    }

    private void LoadProfile()
    {
        var receiver = GetCurrentReceiver();
        if (receiver is null)
        {
            return;
        }

        txtBloodGroupNeeded.Text = receiver.BloodGroupNeeded;
        txtPhone.Text = receiver.Phone;
        txtAddress.Text = receiver.Address;
    }

    private void btnSaveProfile_Click(object sender, EventArgs e)
    {
        if (!Ready())
        {
            return;
        }

        if (string.IsNullOrWhiteSpace(txtBloodGroupNeeded.Text) || string.IsNullOrWhiteSpace(txtPhone.Text) || string.IsNullOrWhiteSpace(txtAddress.Text))
        {
            MessageBox.Show("Please fill profile fields.", "BloodConnect", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        var saved = _receiverService!.UpsertReceiverProfile(
            _user.UserId,
            txtBloodGroupNeeded.Text.Trim(),
            txtPhone.Text.Trim(),
            txtAddress.Text.Trim());

        MessageBox.Show(saved ? "Profile saved." : "Could not save profile.", "BloodConnect", MessageBoxButtons.OK, saved ? MessageBoxIcon.Information : MessageBoxIcon.Error);
    }

    private void btnSearchStock_Click(object sender, EventArgs e)
    {
        if (!Ready())
        {
            return;
        }

        var group = NormalizeBlank(txtSearchGroup.Text);
        var location = NormalizeBlank(txtSearchLocation.Text);

        var list = _receiverService!.SearchBloodStock(group, location)
            .Select(x => new
            {
                Id = x.StockId,
                x.BloodGroup,
                x.Quantity,
                x.HospitalName
            })
            .ToList();

        dgvStock.DataSource = list;
    }

    private void btnSendRequest_Click(object sender, EventArgs e)
    {
        if (!Ready())
        {
            return;
        }

        var receiver = GetCurrentReceiver();
        if (receiver is null)
        {
            MessageBox.Show("Profile not found. Save profile first.", "BloodConnect", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        if (string.IsNullOrWhiteSpace(txtRequestGroup.Text))
        {
            MessageBox.Show("Enter blood group.", "BloodConnect", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        var sent = _receiverService!.SendBloodRequest(
            receiver.ReceiverId,
            txtRequestGroup.Text.Trim(),
            Convert.ToInt32(nudQuantity.Value));

        MessageBox.Show(sent ? "Request sent." : "Could not send request.", "BloodConnect", MessageBoxButtons.OK, sent ? MessageBoxIcon.Information : MessageBoxIcon.Error);
        RefreshRequests();
    }

    private void btnRefreshRequests_Click(object sender, EventArgs e)
    {
        if (Ready())
        {
            RefreshRequests();
        }
    }

    private void btnDeleteRequest_Click(object sender, EventArgs e)
    {
        if (!Ready())
        {
            return;
        }

        var receiver = GetCurrentReceiver();
        if (receiver is null)
        {
            return;
        }

        if (!TryGetSelectedId(dgvRequests, out var requestId))
        {
            MessageBox.Show("Select request row first.", "BloodConnect", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        var deleted = _receiverService!.DeletePendingRequest(receiver.ReceiverId, requestId);
        MessageBox.Show(deleted ? "Pending request deleted." : "Could not delete request.", "BloodConnect", MessageBoxButtons.OK, deleted ? MessageBoxIcon.Information : MessageBoxIcon.Warning);
        RefreshRequests();
    }

    private void RefreshRequests()
    {
        var receiver = GetCurrentReceiver();
        if (receiver is null)
        {
            dgvRequests.DataSource = null;
            return;
        }

        var list = _receiverService!.GetRequestsByReceiver(receiver.ReceiverId)
            .Select(x => new
            {
                Id = x.RequestId,
                x.BloodGroup,
                x.Quantity,
                x.Status,
                Date = x.RequestDate.ToString("yyyy-MM-dd HH:mm")
            })
            .ToList();

        dgvRequests.DataSource = list;
    }

    private void btnRefreshHospitals_Click(object sender, EventArgs e)
    {
        if (Ready())
        {
            RefreshHospitals();
        }
    }

    private void RefreshHospitals()
    {
        var hospitals = _receiverService!.GetAvailableHospitals();
        lstHospitals.DataSource = hospitals.ToList();
    }

    private static bool TryGetSelectedId(DataGridView grid, out int id)
    {
        id = 0;
        if (grid.CurrentRow is null || grid.CurrentRow.Cells.Count == 0)
        {
            return false;
        }

        return int.TryParse(grid.CurrentRow.Cells[0].Value?.ToString(), out id);
    }

    private static string? NormalizeBlank(string value)
    {
        var text = value.Trim();
        return string.IsNullOrWhiteSpace(text) ? null : text;
    }

    private void btnLogout_Click(object sender, EventArgs e)
    {
        Close();
    }
}
