namespace BloodConnect.Models;

public class BloodRequest
{
    public int RequestId { get; set; }
    public int ReceiverId { get; set; }
    public string BloodGroup { get; set; } = string.Empty;
    public int Quantity { get; set; }
    public string Status { get; set; } = string.Empty;
    public DateTime RequestDate { get; set; }
}
