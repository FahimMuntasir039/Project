namespace BloodConnect.Models;

public class BloodStock
{
    public int StockId { get; set; }
    public string BloodGroup { get; set; } = string.Empty;
    public int Quantity { get; set; }
    public string HospitalName { get; set; } = string.Empty;
}
