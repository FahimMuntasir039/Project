namespace BloodConnect.Models;

public class DonationAppointment
{
    public int AppointmentId { get; set; }
    public int DonorId { get; set; }
    public DateTime AppointmentDate { get; set; }
    public string Status { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }
}
