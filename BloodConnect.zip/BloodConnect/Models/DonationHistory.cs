namespace BloodConnect.Models;

public class DonationHistory
{
    public int HistoryId { get; set; }
    public int DonorId { get; set; }
    public string BloodGroup { get; set; } = string.Empty;
    public DateTime DonationDate { get; set; }
    public int Quantity { get; set; }
}
