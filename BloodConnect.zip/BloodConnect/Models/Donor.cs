namespace BloodConnect.Models;

public class Donor
{
    public int DonorId { get; set; }
    public int UserId { get; set; }
    public string BloodGroup { get; set; } = string.Empty;
    public int Age { get; set; }
    public string Phone { get; set; } = string.Empty;
    public string Address { get; set; } = string.Empty;
    public DateTime? LastDonationDate { get; set; }
}
