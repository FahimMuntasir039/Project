namespace BloodConnect.Models;

public class Receiver
{
    public int ReceiverId { get; set; }
    public int UserId { get; set; }
    public string BloodGroupNeeded { get; set; } = string.Empty;
    public string Phone { get; set; } = string.Empty;
    public string Address { get; set; } = string.Empty;
}
