namespace BloodConnect.Models;

public static class Roles
{
    public const string Donor = "Donor";
    public const string Receiver = "Receiver";
    public const string Admin = "Admin";
}
