using BloodConnect.Data;
using BloodConnect.Forms;
using BloodConnect.Services;

namespace BloodConnect;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        ApplicationConfiguration.Initialize();

        try
        {
            var database = new SqlDatabase(DatabaseConfig.ConnectionString);
            var initializer = new DatabaseInitializer(database);
            initializer.Initialize();

            var authService = new AuthService(database);
            authService.EnsureDefaultAdmin();

            Application.Run(
                new LoginForm(
                    authService,
                    new DonorService(database),
                    new ReceiverService(database),
                    new AdminService(database)));
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                $"Could not start BloodConnect.\n\nCheck SQL Server setup and connection string in Data/DatabaseConfig.cs.\n\nDetails: {ex.Message}",
                "Startup Error",
                MessageBoxButtons.OK,
                MessageBoxIcon.Error);
        }
    }
}
