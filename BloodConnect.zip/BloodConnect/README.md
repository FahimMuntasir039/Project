# BloodConnect (C# OOP Project)

BloodConnect is a Windows Forms (GUI) blood donation management application for an OOP course project.
It supports 3 user roles:
- Donor
- Blood Receiver
- Admin

The application uses SQL Server and supports key operations including search, update, and delete.

## Features

### Donor
- Register/login
- Update blood group, age, address, phone, last donation date
- View donation eligibility
- Request donation appointment
- View donation history
- View urgent blood requests
- Delete pending appointment

### Receiver
- Register/login
- Search blood by group and location
- Send blood request
- Track request status
- View available hospitals/blood banks
- Update profile
- Delete pending blood request

### Admin
- Login
- Manage donor records (search/delete)
- Manage blood receiver requests (search/update/delete)
- Update blood stock
- Schedule donation appointments
- Generate summary reports
- Delete stock entries

## Database Tables
- Users
- Donors
- Receivers
- BloodRequests
- BloodStock
- DonationAppointments
- DonationHistory

## Default Admin Account
- Email: `admin@bloodconnect.com`
- Password: `admin123`

## Project Structure
- `Data/` - database config, helper, schema initializer
- `Models/` - OOP entity classes
- `Services/` - business logic per role
- `Forms/` - WinForms GUI (Designer drag-and-drop forms)
- `Database/schema.sql` - SQL script for manual setup

## Setup
1. Ensure SQL Server is running (example: `localhost\SQLEXPRESS`).
2. Connection string is in `Data/DatabaseConfig.cs`:
   - Default: `Server=localhost\\SQLEXPRESS;Database=BloodConnectDb;Trusted_Connection=True;MultipleActiveResultSets=true;Encrypt=True;TrustServerCertificate=True`
3. Optional manual DB setup:
   - Run `Database/schema.sql` in SQL Server Management Studio.

## Run in Visual Studio (Recommended)
1. Open Visual Studio.
2. Click `File > Open > Project/Solution`.
3. Select `BloodConnect.csproj`.
4. Press `Ctrl + F5` to run (or `F5` to run with debugger).

## Drag-and-Drop GUI Editing (Visual Studio)
1. In Solution Explorer, expand `Forms`.
2. Right-click a form such as `LoginForm.cs` and click `View Designer`.
3. Open `View > Toolbox` and drag controls (Label, TextBox, Button, TabControl, DataGridView) onto the form.
4. Click a control and edit properties in `View > Properties Window` (Name, Text, Size, Font, BackColor).
5. Double-click a Button in Designer to auto-create its click event in the `.cs` file.
6. Avoid manually editing `*.Designer.cs` unless necessary; use Designer for layout changes.

## Build and Run from Terminal
From the project directory:

```powershell
dotnet restore --configfile .\NuGet.Config
dotnet run
```

## Note
Passwords are stored in plain text for academic simplicity. For real production apps, use salted password hashing and proper authentication.
