using System.Data;
using Microsoft.Data.SqlClient;
using BloodConnect.Data;
using BloodConnect.Models;

namespace BloodConnect.Services;

public class AdminService
{
    private readonly SqlDatabase _database;

    public AdminService(SqlDatabase database)
    {
        _database = database;
    }

    public IReadOnlyList<Donor> SearchDonors(string? bloodGroup)
    {
        var sql = @"
SELECT DonorId, UserId, BloodGroup, Age, Phone, Address, LastDonationDate
FROM Donors
WHERE 1 = 1";

        var parameters = new List<SqlParameter>();
        if (!string.IsNullOrWhiteSpace(bloodGroup))
        {
            sql += " AND BloodGroup = @BloodGroup";
            parameters.Add(new SqlParameter("@BloodGroup", bloodGroup));
        }

        sql += " ORDER BY DonorId;";

        var table = _database.Query(sql, parameters.ToArray());
        return table.Rows.Cast<DataRow>().Select(MapDonor).ToList();
    }

    public bool DeleteDonor(int donorId)
    {
        const string sql = "DELETE FROM Donors WHERE DonorId = @DonorId;";
        return _database.ExecuteNonQuery(sql, new SqlParameter("@DonorId", donorId)) > 0;
    }

    public IReadOnlyList<BloodRequest> SearchRequests(string? status, string? bloodGroup)
    {
        var sql = @"
SELECT RequestId, ReceiverId, BloodGroup, Quantity, Status, RequestDate
FROM BloodRequests
WHERE 1 = 1";

        var parameters = new List<SqlParameter>();

        if (!string.IsNullOrWhiteSpace(status))
        {
            sql += " AND Status = @Status";
            parameters.Add(new SqlParameter("@Status", status));
        }

        if (!string.IsNullOrWhiteSpace(bloodGroup))
        {
            sql += " AND BloodGroup = @BloodGroup";
            parameters.Add(new SqlParameter("@BloodGroup", bloodGroup));
        }

        sql += " ORDER BY RequestDate DESC;";

        var table = _database.Query(sql, parameters.ToArray());
        return table.Rows.Cast<DataRow>().Select(MapRequest).ToList();
    }

    public bool UpdateRequestStatus(int requestId, string newStatus)
    {
        const string sql = @"
UPDATE BloodRequests
SET Status = @Status
WHERE RequestId = @RequestId;";

        return _database.ExecuteNonQuery(
            sql,
            new SqlParameter("@Status", newStatus),
            new SqlParameter("@RequestId", requestId)) > 0;
    }

    public bool DeleteRequest(int requestId)
    {
        const string sql = "DELETE FROM BloodRequests WHERE RequestId = @RequestId;";
        return _database.ExecuteNonQuery(sql, new SqlParameter("@RequestId", requestId)) > 0;
    }

    public bool UpsertBloodStock(string bloodGroup, int quantity, string hospitalName)
    {
        const string existsSql = @"
SELECT COUNT(1)
FROM BloodStock
WHERE BloodGroup = @BloodGroup
  AND HospitalName = @HospitalName;";

        var exists = _database.ExecuteScalar<int>(
            existsSql,
            new SqlParameter("@BloodGroup", bloodGroup),
            new SqlParameter("@HospitalName", hospitalName));

        if (exists == 0)
        {
            const string insertSql = @"
INSERT INTO BloodStock (BloodGroup, Quantity, HospitalName)
VALUES (@BloodGroup, @Quantity, @HospitalName);";

            return _database.ExecuteNonQuery(
                insertSql,
                new SqlParameter("@BloodGroup", bloodGroup),
                new SqlParameter("@Quantity", quantity),
                new SqlParameter("@HospitalName", hospitalName)) > 0;
        }

        const string updateSql = @"
UPDATE BloodStock
SET Quantity = @Quantity
WHERE BloodGroup = @BloodGroup
  AND HospitalName = @HospitalName;";

        return _database.ExecuteNonQuery(
            updateSql,
            new SqlParameter("@Quantity", quantity),
            new SqlParameter("@BloodGroup", bloodGroup),
            new SqlParameter("@HospitalName", hospitalName)) > 0;
    }

    public bool DeleteBloodStock(int stockId)
    {
        const string sql = "DELETE FROM BloodStock WHERE StockId = @StockId;";
        return _database.ExecuteNonQuery(sql, new SqlParameter("@StockId", stockId)) > 0;
    }

    public IReadOnlyList<BloodStock> GetAllBloodStock()
    {
        const string sql = @"
SELECT StockId, BloodGroup, Quantity, HospitalName
FROM BloodStock
ORDER BY HospitalName, BloodGroup;";

        var table = _database.Query(sql);
        return table.Rows.Cast<DataRow>().Select(MapStock).ToList();
    }

    public bool ScheduleAppointment(int donorId, DateTime appointmentDate, string status)
    {
        const string sql = @"
INSERT INTO DonationAppointments (DonorId, AppointmentDate, Status)
VALUES (@DonorId, @AppointmentDate, @Status);";

        return _database.ExecuteNonQuery(
            sql,
            new SqlParameter("@DonorId", donorId),
            new SqlParameter("@AppointmentDate", appointmentDate),
            new SqlParameter("@Status", status)) > 0;
    }

    public IReadOnlyDictionary<string, int> GenerateReport()
    {
        var report = new Dictionary<string, int>
        {
            ["Total Users"] = _database.ExecuteScalar<int>("SELECT COUNT(1) FROM Users;"),
            ["Total Donors"] = _database.ExecuteScalar<int>("SELECT COUNT(1) FROM Donors;"),
            ["Total Receivers"] = _database.ExecuteScalar<int>("SELECT COUNT(1) FROM Receivers;"),
            ["Pending Requests"] = _database.ExecuteScalar<int>("SELECT COUNT(1) FROM BloodRequests WHERE Status = 'Pending';"),
            ["Approved Requests"] = _database.ExecuteScalar<int>("SELECT COUNT(1) FROM BloodRequests WHERE Status = 'Approved';"),
            ["Total Blood Units In Stock"] = _database.ExecuteScalar<int>("SELECT ISNULL(SUM(Quantity), 0) FROM BloodStock;")
        };

        return report;
    }

    private static Donor MapDonor(DataRow row)
    {
        return new Donor
        {
            DonorId = Convert.ToInt32(row["DonorId"]),
            UserId = Convert.ToInt32(row["UserId"]),
            BloodGroup = Convert.ToString(row["BloodGroup"]) ?? string.Empty,
            Age = Convert.ToInt32(row["Age"]),
            Phone = Convert.ToString(row["Phone"]) ?? string.Empty,
            Address = Convert.ToString(row["Address"]) ?? string.Empty,
            LastDonationDate = row["LastDonationDate"] == DBNull.Value
                ? null
                : Convert.ToDateTime(row["LastDonationDate"])
        };
    }

    private static BloodRequest MapRequest(DataRow row)
    {
        return new BloodRequest
        {
            RequestId = Convert.ToInt32(row["RequestId"]),
            ReceiverId = Convert.ToInt32(row["ReceiverId"]),
            BloodGroup = Convert.ToString(row["BloodGroup"]) ?? string.Empty,
            Quantity = Convert.ToInt32(row["Quantity"]),
            Status = Convert.ToString(row["Status"]) ?? string.Empty,
            RequestDate = Convert.ToDateTime(row["RequestDate"])
        };
    }

    private static BloodStock MapStock(DataRow row)
    {
        return new BloodStock
        {
            StockId = Convert.ToInt32(row["StockId"]),
            BloodGroup = Convert.ToString(row["BloodGroup"]) ?? string.Empty,
            Quantity = Convert.ToInt32(row["Quantity"]),
            HospitalName = Convert.ToString(row["HospitalName"]) ?? string.Empty
        };
    }
}
