using System.Data;
using Microsoft.Data.SqlClient;
using BloodConnect.Data;
using BloodConnect.Models;

namespace BloodConnect.Services;

public class AuthService
{
    private readonly SqlDatabase _database;

    public AuthService(SqlDatabase database)
    {
        _database = database;
    }

    public void EnsureDefaultAdmin()
    {
        const string sql = "SELECT COUNT(1) FROM Users WHERE Role = @Role";
        var count = _database.ExecuteScalar<int>(sql, new SqlParameter("@Role", Roles.Admin));

        if (count > 0)
        {
            return;
        }

        RegisterUser("System Admin", "admin@bloodconnect.com", "admin123", Roles.Admin);
    }

    public int RegisterUser(string name, string email, string password, string role)
    {
        const string existsSql = "SELECT COUNT(1) FROM Users WHERE Email = @Email";
        var exists = _database.ExecuteScalar<int>(existsSql, new SqlParameter("@Email", email));

        if (exists > 0)
        {
            return -1;
        }

        const string insertSql = @"
INSERT INTO Users (Name, Email, Password, Role)
VALUES (@Name, @Email, @Password, @Role);
SELECT CAST(SCOPE_IDENTITY() AS INT);";

        return _database.ExecuteScalar<int>(
            insertSql,
            new SqlParameter("@Name", name),
            new SqlParameter("@Email", email),
            new SqlParameter("@Password", password),
            new SqlParameter("@Role", role));
    }

    public User? Login(string email, string password)
    {
        const string sql = @"
SELECT TOP 1 UserId, Name, Email, Password, Role
FROM Users
WHERE Email = @Email AND Password = @Password;";

        var table = _database.Query(
            sql,
            new SqlParameter("@Email", email),
            new SqlParameter("@Password", password));

        if (table.Rows.Count == 0)
        {
            return null;
        }

        return MapUser(table.Rows[0]);
    }

    private static User MapUser(DataRow row)
    {
        return new User
        {
            UserId = Convert.ToInt32(row["UserId"]),
            Name = Convert.ToString(row["Name"]) ?? string.Empty,
            Email = Convert.ToString(row["Email"]) ?? string.Empty,
            Password = Convert.ToString(row["Password"]) ?? string.Empty,
            Role = Convert.ToString(row["Role"]) ?? string.Empty
        };
    }
}
