using System.Data;
using Microsoft.Data.SqlClient;
using BloodConnect.Data;
using BloodConnect.Models;

namespace BloodConnect.Services;

public class DonorService
{
    private readonly SqlDatabase _database;

    public DonorService(SqlDatabase database)
    {
        _database = database;
    }

    public Donor? GetDonorByUserId(int userId)
    {
        const string sql = @"
SELECT TOP 1 DonorId, UserId, BloodGroup, Age, Phone, Address, LastDonationDate
FROM Donors
WHERE UserId = @UserId;";

        var table = _database.Query(sql, new SqlParameter("@UserId", userId));
        if (table.Rows.Count == 0)
        {
            return null;
        }

        return MapDonor(table.Rows[0]);
    }

    public bool UpsertDonorProfile(int userId, string bloodGroup, int age, string phone, string address, DateTime? lastDonationDate)
    {
        var donor = GetDonorByUserId(userId);

        if (donor is null)
        {
            const string insertSql = @"
INSERT INTO Donors (UserId, BloodGroup, Age, Phone, Address, LastDonationDate)
VALUES (@UserId, @BloodGroup, @Age, @Phone, @Address, @LastDonationDate);";

            return _database.ExecuteNonQuery(
                insertSql,
                new SqlParameter("@UserId", userId),
                new SqlParameter("@BloodGroup", bloodGroup),
                new SqlParameter("@Age", age),
                new SqlParameter("@Phone", phone),
                new SqlParameter("@Address", address),
                new SqlParameter("@LastDonationDate", (object?)lastDonationDate ?? DBNull.Value)) > 0;
        }

        const string updateSql = @"
UPDATE Donors
SET BloodGroup = @BloodGroup,
    Age = @Age,
    Phone = @Phone,
    Address = @Address,
    LastDonationDate = @LastDonationDate
WHERE UserId = @UserId;";

        return _database.ExecuteNonQuery(
            updateSql,
            new SqlParameter("@BloodGroup", bloodGroup),
            new SqlParameter("@Age", age),
            new SqlParameter("@Phone", phone),
            new SqlParameter("@Address", address),
            new SqlParameter("@LastDonationDate", (object?)lastDonationDate ?? DBNull.Value),
            new SqlParameter("@UserId", userId)) > 0;
    }

    public (bool IsEligible, string Reason) CheckEligibility(int donorId)
    {
        const string sql = @"
SELECT TOP 1 Age, LastDonationDate
FROM Donors
WHERE DonorId = @DonorId;";

        var table = _database.Query(sql, new SqlParameter("@DonorId", donorId));
        if (table.Rows.Count == 0)
        {
            return (false, "Donor profile not found.");
        }

        var row = table.Rows[0];
        var age = Convert.ToInt32(row["Age"]);

        if (age < 18 || age > 60)
        {
            return (false, "Age must be between 18 and 60.");
        }

        DateTime? lastDate = row["LastDonationDate"] == DBNull.Value
            ? null
            : Convert.ToDateTime(row["LastDonationDate"]);

        if (lastDate is null)
        {
            return (true, "Eligible. No previous donation date recorded.");
        }

        var daysSinceLastDonation = (DateTime.Today - lastDate.Value.Date).TotalDays;
        if (daysSinceLastDonation < 90)
        {
            return (false, $"Not eligible yet. Wait {90 - (int)daysSinceLastDonation} more day(s).");
        }

        return (true, "Eligible to donate.");
    }

    public bool RequestAppointment(int donorId, DateTime appointmentDate)
    {
        const string sql = @"
INSERT INTO DonationAppointments (DonorId, AppointmentDate, Status)
VALUES (@DonorId, @AppointmentDate, 'Pending');";

        return _database.ExecuteNonQuery(
            sql,
            new SqlParameter("@DonorId", donorId),
            new SqlParameter("@AppointmentDate", appointmentDate)) > 0;
    }

    public IReadOnlyList<DonationAppointment> GetAppointments(int donorId)
    {
        const string sql = @"
SELECT AppointmentId, DonorId, AppointmentDate, Status, CreatedAt
FROM DonationAppointments
WHERE DonorId = @DonorId
ORDER BY AppointmentDate DESC;";

        var table = _database.Query(sql, new SqlParameter("@DonorId", donorId));
        return table.Rows.Cast<DataRow>().Select(MapAppointment).ToList();
    }

    public bool DeletePendingAppointment(int donorId, int appointmentId)
    {
        const string sql = @"
DELETE FROM DonationAppointments
WHERE DonorId = @DonorId
  AND AppointmentId = @AppointmentId
  AND Status = 'Pending';";

        return _database.ExecuteNonQuery(
            sql,
            new SqlParameter("@DonorId", donorId),
            new SqlParameter("@AppointmentId", appointmentId)) > 0;
    }

    public IReadOnlyList<DonationHistory> GetDonationHistory(int donorId)
    {
        const string sql = @"
SELECT HistoryId, DonorId, BloodGroup, DonationDate, Quantity
FROM DonationHistory
WHERE DonorId = @DonorId
ORDER BY DonationDate DESC;";

        var table = _database.Query(sql, new SqlParameter("@DonorId", donorId));
        return table.Rows.Cast<DataRow>().Select(MapHistory).ToList();
    }

    public IReadOnlyList<BloodRequest> GetUrgentRequests()
    {
        const string sql = @"
SELECT TOP 20 RequestId, ReceiverId, BloodGroup, Quantity, Status, RequestDate
FROM BloodRequests
WHERE Status = 'Pending'
ORDER BY RequestDate DESC;";

        var table = _database.Query(sql);
        return table.Rows.Cast<DataRow>().Select(MapRequest).ToList();
    }

    private static Donor MapDonor(DataRow row)
    {
        return new Donor
        {
            DonorId = Convert.ToInt32(row["DonorId"]),
            UserId = Convert.ToInt32(row["UserId"]),
            BloodGroup = Convert.ToString(row["BloodGroup"]) ?? string.Empty,
            Age = Convert.ToInt32(row["Age"]),
            Phone = Convert.ToString(row["Phone"]) ?? string.Empty,
            Address = Convert.ToString(row["Address"]) ?? string.Empty,
            LastDonationDate = row["LastDonationDate"] == DBNull.Value
                ? null
                : Convert.ToDateTime(row["LastDonationDate"])
        };
    }

    private static DonationAppointment MapAppointment(DataRow row)
    {
        return new DonationAppointment
        {
            AppointmentId = Convert.ToInt32(row["AppointmentId"]),
            DonorId = Convert.ToInt32(row["DonorId"]),
            AppointmentDate = Convert.ToDateTime(row["AppointmentDate"]),
            Status = Convert.ToString(row["Status"]) ?? string.Empty,
            CreatedAt = Convert.ToDateTime(row["CreatedAt"])
        };
    }

    private static DonationHistory MapHistory(DataRow row)
    {
        return new DonationHistory
        {
            HistoryId = Convert.ToInt32(row["HistoryId"]),
            DonorId = Convert.ToInt32(row["DonorId"]),
            BloodGroup = Convert.ToString(row["BloodGroup"]) ?? string.Empty,
            DonationDate = Convert.ToDateTime(row["DonationDate"]),
            Quantity = Convert.ToInt32(row["Quantity"])
        };
    }

    private static BloodRequest MapRequest(DataRow row)
    {
        return new BloodRequest
        {
            RequestId = Convert.ToInt32(row["RequestId"]),
            ReceiverId = Convert.ToInt32(row["ReceiverId"]),
            BloodGroup = Convert.ToString(row["BloodGroup"]) ?? string.Empty,
            Quantity = Convert.ToInt32(row["Quantity"]),
            Status = Convert.ToString(row["Status"]) ?? string.Empty,
            RequestDate = Convert.ToDateTime(row["RequestDate"])
        };
    }
}
