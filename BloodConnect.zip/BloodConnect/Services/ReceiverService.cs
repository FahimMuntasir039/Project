using System.Data;
using Microsoft.Data.SqlClient;
using BloodConnect.Data;
using BloodConnect.Models;

namespace BloodConnect.Services;

public class ReceiverService
{
    private readonly SqlDatabase _database;

    public ReceiverService(SqlDatabase database)
    {
        _database = database;
    }

    public Receiver? GetReceiverByUserId(int userId)
    {
        const string sql = @"
SELECT TOP 1 ReceiverId, UserId, BloodGroupNeeded, Phone, Address
FROM Receivers
WHERE UserId = @UserId;";

        var table = _database.Query(sql, new SqlParameter("@UserId", userId));
        if (table.Rows.Count == 0)
        {
            return null;
        }

        return MapReceiver(table.Rows[0]);
    }

    public bool UpsertReceiverProfile(int userId, string bloodGroupNeeded, string phone, string address)
    {
        var receiver = GetReceiverByUserId(userId);

        if (receiver is null)
        {
            const string insertSql = @"
INSERT INTO Receivers (UserId, BloodGroupNeeded, Phone, Address)
VALUES (@UserId, @BloodGroupNeeded, @Phone, @Address);";

            return _database.ExecuteNonQuery(
                insertSql,
                new SqlParameter("@UserId", userId),
                new SqlParameter("@BloodGroupNeeded", bloodGroupNeeded),
                new SqlParameter("@Phone", phone),
                new SqlParameter("@Address", address)) > 0;
        }

        const string updateSql = @"
UPDATE Receivers
SET BloodGroupNeeded = @BloodGroupNeeded,
    Phone = @Phone,
    Address = @Address
WHERE UserId = @UserId;";

        return _database.ExecuteNonQuery(
            updateSql,
            new SqlParameter("@BloodGroupNeeded", bloodGroupNeeded),
            new SqlParameter("@Phone", phone),
            new SqlParameter("@Address", address),
            new SqlParameter("@UserId", userId)) > 0;
    }

    public IReadOnlyList<BloodStock> SearchBloodStock(string? bloodGroup, string? location)
    {
        var sql = @"
SELECT StockId, BloodGroup, Quantity, HospitalName
FROM BloodStock
WHERE Quantity > 0";

        var parameters = new List<SqlParameter>();

        if (!string.IsNullOrWhiteSpace(bloodGroup))
        {
            sql += " AND BloodGroup = @BloodGroup";
            parameters.Add(new SqlParameter("@BloodGroup", bloodGroup));
        }

        if (!string.IsNullOrWhiteSpace(location))
        {
            sql += " AND HospitalName LIKE @Location";
            parameters.Add(new SqlParameter("@Location", $"%{location}%"));
        }

        sql += " ORDER BY HospitalName;";

        var table = _database.Query(sql, parameters.ToArray());
        return table.Rows.Cast<DataRow>().Select(MapBloodStock).ToList();
    }

    public bool SendBloodRequest(int receiverId, string bloodGroup, int quantity)
    {
        const string sql = @"
INSERT INTO BloodRequests (ReceiverId, BloodGroup, Quantity, Status)
VALUES (@ReceiverId, @BloodGroup, @Quantity, 'Pending');";

        return _database.ExecuteNonQuery(
            sql,
            new SqlParameter("@ReceiverId", receiverId),
            new SqlParameter("@BloodGroup", bloodGroup),
            new SqlParameter("@Quantity", quantity)) > 0;
    }

    public IReadOnlyList<BloodRequest> GetRequestsByReceiver(int receiverId)
    {
        const string sql = @"
SELECT RequestId, ReceiverId, BloodGroup, Quantity, Status, RequestDate
FROM BloodRequests
WHERE ReceiverId = @ReceiverId
ORDER BY RequestDate DESC;";

        var table = _database.Query(sql, new SqlParameter("@ReceiverId", receiverId));
        return table.Rows.Cast<DataRow>().Select(MapRequest).ToList();
    }

    public bool DeletePendingRequest(int receiverId, int requestId)
    {
        const string sql = @"
DELETE FROM BloodRequests
WHERE ReceiverId = @ReceiverId
  AND RequestId = @RequestId
  AND Status = 'Pending';";

        return _database.ExecuteNonQuery(
            sql,
            new SqlParameter("@ReceiverId", receiverId),
            new SqlParameter("@RequestId", requestId)) > 0;
    }

    public IReadOnlyList<string> GetAvailableHospitals()
    {
        const string sql = @"
SELECT DISTINCT HospitalName
FROM BloodStock
WHERE Quantity > 0
ORDER BY HospitalName;";

        var table = _database.Query(sql);
        return table.Rows.Cast<DataRow>().Select(row => Convert.ToString(row["HospitalName"]) ?? string.Empty).ToList();
    }

    private static Receiver MapReceiver(DataRow row)
    {
        return new Receiver
        {
            ReceiverId = Convert.ToInt32(row["ReceiverId"]),
            UserId = Convert.ToInt32(row["UserId"]),
            BloodGroupNeeded = Convert.ToString(row["BloodGroupNeeded"]) ?? string.Empty,
            Phone = Convert.ToString(row["Phone"]) ?? string.Empty,
            Address = Convert.ToString(row["Address"]) ?? string.Empty
        };
    }

    private static BloodStock MapBloodStock(DataRow row)
    {
        return new BloodStock
        {
            StockId = Convert.ToInt32(row["StockId"]),
            BloodGroup = Convert.ToString(row["BloodGroup"]) ?? string.Empty,
            Quantity = Convert.ToInt32(row["Quantity"]),
            HospitalName = Convert.ToString(row["HospitalName"]) ?? string.Empty
        };
    }

    private static BloodRequest MapRequest(DataRow row)
    {
        return new BloodRequest
        {
            RequestId = Convert.ToInt32(row["RequestId"]),
            ReceiverId = Convert.ToInt32(row["ReceiverId"]),
            BloodGroup = Convert.ToString(row["BloodGroup"]) ?? string.Empty,
            Quantity = Convert.ToInt32(row["Quantity"]),
            Status = Convert.ToString(row["Status"]) ?? string.Empty,
            RequestDate = Convert.ToDateTime(row["RequestDate"])
        };
    }
}
