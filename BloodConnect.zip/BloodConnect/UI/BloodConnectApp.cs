using BloodConnect.Models;
using BloodConnect.Services;

namespace BloodConnect.UI;

public class BloodConnectApp
{
    private readonly AuthService _authService;
    private readonly DonorService _donorService;
    private readonly ReceiverService _receiverService;
    private readonly AdminService _adminService;

    public BloodConnectApp(
        AuthService authService,
        DonorService donorService,
        ReceiverService receiverService,
        AdminService adminService)
    {
        _authService = authService;
        _donorService = donorService;
        _receiverService = receiverService;
        _adminService = adminService;
    }

    public void Run()
    {
        while (true)
        {
            Console.WriteLine();
            Console.WriteLine("==========================");
            Console.WriteLine("      BloodConnect App    ");
            Console.WriteLine("==========================");
            Console.WriteLine("1. Register as Donor");
            Console.WriteLine("2. Register as Receiver");
            Console.WriteLine("3. Login");
            Console.WriteLine("4. Exit");

            var choice = ReadRequiredString("Select option: ");
            Console.WriteLine();

            switch (choice)
            {
                case "1":
                    RegisterDonor();
                    break;
                case "2":
                    RegisterReceiver();
                    break;
                case "3":
                    Login();
                    break;
                case "4":
                    Console.WriteLine("Thanks for using BloodConnect.");
                    return;
                default:
                    Console.WriteLine("Invalid option.");
                    break;
            }
        }
    }

    private void RegisterDonor()
    {
        Console.WriteLine("--- Donor Registration ---");
        var name = ReadRequiredString("Name: ");
        var email = ReadRequiredString("Email: ");
        var password = ReadRequiredString("Password: ");

        var userId = _authService.RegisterUser(name, email, password, Roles.Donor);
        if (userId < 0)
        {
            Console.WriteLine("This email is already used.");
            return;
        }

        var bloodGroup = ReadRequiredString("Blood group (A+/A-/B+/B-/AB+/AB-/O+/O-): ");
        var age = ReadInt("Age: ", 1, 120);
        var phone = ReadRequiredString("Phone: ");
        var address = ReadRequiredString("Address: ");
        var lastDonationDate = ReadOptionalDate("Last donation date (yyyy-mm-dd, blank if none): ");

        var saved = _donorService.UpsertDonorProfile(userId, bloodGroup, age, phone, address, lastDonationDate);
        Console.WriteLine(saved ? "Donor registered successfully." : "Could not save donor profile.");
    }

    private void RegisterReceiver()
    {
        Console.WriteLine("--- Receiver Registration ---");
        var name = ReadRequiredString("Name: ");
        var email = ReadRequiredString("Email: ");
        var password = ReadRequiredString("Password: ");

        var userId = _authService.RegisterUser(name, email, password, Roles.Receiver);
        if (userId < 0)
        {
            Console.WriteLine("This email is already used.");
            return;
        }

        var bloodGroupNeeded = ReadRequiredString("Blood group needed: ");
        var phone = ReadRequiredString("Phone: ");
        var address = ReadRequiredString("Address: ");

        var saved = _receiverService.UpsertReceiverProfile(userId, bloodGroupNeeded, phone, address);
        Console.WriteLine(saved ? "Receiver registered successfully." : "Could not save receiver profile.");
    }

    private void Login()
    {
        Console.WriteLine("--- Login ---");
        var email = ReadRequiredString("Email: ");
        var password = ReadRequiredString("Password: ");

        var user = _authService.Login(email, password);
        if (user is null)
        {
            Console.WriteLine("Invalid email or password.");
            return;
        }

        Console.WriteLine($"Welcome, {user.Name} ({user.Role})");

        switch (user.Role)
        {
            case Roles.Donor:
                DonorMenu(user);
                break;
            case Roles.Receiver:
                ReceiverMenu(user);
                break;
            case Roles.Admin:
                AdminMenu();
                break;
            default:
                Console.WriteLine("Unsupported role.");
                break;
        }
    }

    private void DonorMenu(User user)
    {
        while (true)
        {
            Console.WriteLine();
            Console.WriteLine("--- Donor Menu ---");
            Console.WriteLine("1. View/Update Profile");
            Console.WriteLine("2. View Donation Eligibility");
            Console.WriteLine("3. Request Donation Appointment");
            Console.WriteLine("4. View Donation History");
            Console.WriteLine("5. View Urgent Blood Needs");
            Console.WriteLine("6. Delete Pending Appointment");
            Console.WriteLine("7. Logout");

            var choice = ReadRequiredString("Select option: ");
            Console.WriteLine();

            if (choice == "7")
            {
                return;
            }

            var donor = _donorService.GetDonorByUserId(user.UserId);

            switch (choice)
            {
                case "1":
                    var existingBlood = donor?.BloodGroup;
                    var existingAge = donor?.Age;
                    var existingPhone = donor?.Phone;
                    var existingAddress = donor?.Address;
                    var existingDate = donor?.LastDonationDate;

                    var bloodGroup = ReadRequiredString($"Blood group [{existingBlood ?? "none"}]: ", existingBlood);
                    var age = ReadInt($"Age [{existingAge?.ToString() ?? "none"}]: ", 1, 120, existingAge);
                    var phone = ReadRequiredString($"Phone [{existingPhone ?? "none"}]: ", existingPhone);
                    var address = ReadRequiredString($"Address [{existingAddress ?? "none"}]: ", existingAddress);
                    var date = ReadOptionalDate(
                        $"Last donation date [{existingDate?.ToString("yyyy-MM-dd") ?? "none"}] (yyyy-mm-dd/blank): ",
                        existingDate);

                    var updated = _donorService.UpsertDonorProfile(user.UserId, bloodGroup, age, phone, address, date);
                    Console.WriteLine(updated ? "Donor profile saved." : "Could not save donor profile.");
                    break;

                case "2":
                    if (donor is null)
                    {
                        Console.WriteLine("Create donor profile first.");
                        break;
                    }

                    var eligibility = _donorService.CheckEligibility(donor.DonorId);
                    Console.WriteLine($"Eligible: {(eligibility.IsEligible ? "Yes" : "No")}");
                    Console.WriteLine($"Reason: {eligibility.Reason}");
                    break;

                case "3":
                    if (donor is null)
                    {
                        Console.WriteLine("Create donor profile first.");
                        break;
                    }

                    var appointmentDate = ReadDate("Appointment date (yyyy-mm-dd): ");
                    var requested = _donorService.RequestAppointment(donor.DonorId, appointmentDate);
                    Console.WriteLine(requested ? "Appointment request submitted." : "Could not submit appointment request.");
                    break;

                case "4":
                    if (donor is null)
                    {
                        Console.WriteLine("Create donor profile first.");
                        break;
                    }

                    var history = _donorService.GetDonationHistory(donor.DonorId);
                    if (history.Count == 0)
                    {
                        Console.WriteLine("No donation history found.");
                        break;
                    }

                    Console.WriteLine("HistoryId | Date       | Group | Quantity");
                    foreach (var item in history)
                    {
                        Console.WriteLine($"{item.HistoryId,9} | {item.DonationDate:yyyy-MM-dd} | {item.BloodGroup,5} | {item.Quantity,8}");
                    }

                    break;

                case "5":
                    var urgent = _donorService.GetUrgentRequests();
                    if (urgent.Count == 0)
                    {
                        Console.WriteLine("No urgent requests right now.");
                        break;
                    }

                    Console.WriteLine("RequestId | Group | Quantity | Date       | Status");
                    foreach (var request in urgent)
                    {
                        Console.WriteLine($"{request.RequestId,9} | {request.BloodGroup,5} | {request.Quantity,8} | {request.RequestDate:yyyy-MM-dd} | {request.Status}");
                    }

                    break;

                case "6":
                    if (donor is null)
                    {
                        Console.WriteLine("Create donor profile first.");
                        break;
                    }

                    var appointments = _donorService.GetAppointments(donor.DonorId)
                        .Where(a => a.Status.Equals("Pending", StringComparison.OrdinalIgnoreCase))
                        .ToList();

                    if (appointments.Count == 0)
                    {
                        Console.WriteLine("No pending appointments to delete.");
                        break;
                    }

                    Console.WriteLine("AppointmentId | Date       | Status");
                    foreach (var appointment in appointments)
                    {
                        Console.WriteLine($"{appointment.AppointmentId,13} | {appointment.AppointmentDate:yyyy-MM-dd} | {appointment.Status}");
                    }

                    var appointmentId = ReadInt("AppointmentId to delete: ", 1, int.MaxValue);
                    var deleted = _donorService.DeletePendingAppointment(donor.DonorId, appointmentId);
                    Console.WriteLine(deleted ? "Appointment deleted." : "Appointment not found or not pending.");
                    break;

                default:
                    Console.WriteLine("Invalid option.");
                    break;
            }
        }
    }

    private void ReceiverMenu(User user)
    {
        while (true)
        {
            Console.WriteLine();
            Console.WriteLine("--- Receiver Menu ---");
            Console.WriteLine("1. View/Update Profile");
            Console.WriteLine("2. Search Blood by Group and Location");
            Console.WriteLine("3. Send Blood Request");
            Console.WriteLine("4. Track Request Status");
            Console.WriteLine("5. View Available Hospitals/Blood Banks");
            Console.WriteLine("6. Delete Pending Blood Request");
            Console.WriteLine("7. Logout");

            var choice = ReadRequiredString("Select option: ");
            Console.WriteLine();

            if (choice == "7")
            {
                return;
            }

            var receiver = _receiverService.GetReceiverByUserId(user.UserId);

            switch (choice)
            {
                case "1":
                    var existingGroup = receiver?.BloodGroupNeeded;
                    var existingPhone = receiver?.Phone;
                    var existingAddress = receiver?.Address;

                    var bloodGroupNeeded = ReadRequiredString($"Blood group needed [{existingGroup ?? "none"}]: ", existingGroup);
                    var phone = ReadRequiredString($"Phone [{existingPhone ?? "none"}]: ", existingPhone);
                    var address = ReadRequiredString($"Address [{existingAddress ?? "none"}]: ", existingAddress);

                    var updated = _receiverService.UpsertReceiverProfile(user.UserId, bloodGroupNeeded, phone, address);
                    Console.WriteLine(updated ? "Receiver profile saved." : "Could not save receiver profile.");
                    break;

                case "2":
                    var group = ReadRequiredString("Blood group (or type * for all): ");
                    var location = ReadRequiredString("Location/Hospital (or type * for all): ");

                    var searchGroup = group == "*" ? null : group;
                    var searchLocation = location == "*" ? null : location;
                    var stockList = _receiverService.SearchBloodStock(searchGroup, searchLocation);

                    if (stockList.Count == 0)
                    {
                        Console.WriteLine("No available blood stock found.");
                        break;
                    }

                    Console.WriteLine("StockId | Group | Qty | Hospital");
                    foreach (var stock in stockList)
                    {
                        Console.WriteLine($"{stock.StockId,7} | {stock.BloodGroup,5} | {stock.Quantity,3} | {stock.HospitalName}");
                    }

                    break;

                case "3":
                    if (receiver is null)
                    {
                        Console.WriteLine("Create receiver profile first.");
                        break;
                    }

                    var requestGroup = ReadRequiredString("Required blood group: ");
                    var quantity = ReadInt("Quantity (units): ", 1, 100);
                    var sent = _receiverService.SendBloodRequest(receiver.ReceiverId, requestGroup, quantity);
                    Console.WriteLine(sent ? "Blood request sent successfully." : "Could not send request.");
                    break;

                case "4":
                    if (receiver is null)
                    {
                        Console.WriteLine("Create receiver profile first.");
                        break;
                    }

                    var requests = _receiverService.GetRequestsByReceiver(receiver.ReceiverId);
                    if (requests.Count == 0)
                    {
                        Console.WriteLine("No requests found.");
                        break;
                    }

                    Console.WriteLine("RequestId | Group | Quantity | Status   | Date");
                    foreach (var request in requests)
                    {
                        Console.WriteLine($"{request.RequestId,9} | {request.BloodGroup,5} | {request.Quantity,8} | {request.Status,-8} | {request.RequestDate:yyyy-MM-dd}");
                    }

                    var hasApproved = requests.Any(r => r.Status.Equals("Approved", StringComparison.OrdinalIgnoreCase));
                    if (hasApproved)
                    {
                        Console.WriteLine("At least one request is approved. You can contact hospital staff from option 5.");
                    }

                    break;

                case "5":
                    var hospitals = _receiverService.GetAvailableHospitals();
                    if (hospitals.Count == 0)
                    {
                        Console.WriteLine("No hospitals with stock found.");
                        break;
                    }

                    Console.WriteLine("Available hospitals/blood banks:");
                    foreach (var hospital in hospitals)
                    {
                        Console.WriteLine($"- {hospital}");
                    }

                    break;

                case "6":
                    if (receiver is null)
                    {
                        Console.WriteLine("Create receiver profile first.");
                        break;
                    }

                    var ownRequests = _receiverService.GetRequestsByReceiver(receiver.ReceiverId)
                        .Where(r => r.Status.Equals("Pending", StringComparison.OrdinalIgnoreCase))
                        .ToList();

                    if (ownRequests.Count == 0)
                    {
                        Console.WriteLine("No pending requests to delete.");
                        break;
                    }

                    Console.WriteLine("Pending requests:");
                    foreach (var request in ownRequests)
                    {
                        Console.WriteLine($"RequestId: {request.RequestId}, Group: {request.BloodGroup}, Qty: {request.Quantity}, Date: {request.RequestDate:yyyy-MM-dd}");
                    }

                    var requestId = ReadInt("RequestId to delete: ", 1, int.MaxValue);
                    var deleted = _receiverService.DeletePendingRequest(receiver.ReceiverId, requestId);
                    Console.WriteLine(deleted ? "Request deleted." : "Request not found or not pending.");
                    break;

                default:
                    Console.WriteLine("Invalid option.");
                    break;
            }
        }
    }

    private void AdminMenu()
    {
        while (true)
        {
            Console.WriteLine();
            Console.WriteLine("--- Admin Menu ---");
            Console.WriteLine("1. Manage Donor Records (Search/Delete)");
            Console.WriteLine("2. Manage Blood Receiver Requests");
            Console.WriteLine("3. Update Blood Stock");
            Console.WriteLine("4. Schedule Donation Appointment");
            Console.WriteLine("5. Generate Reports");
            Console.WriteLine("6. Delete Blood Stock Entry");
            Console.WriteLine("7. Logout");

            var choice = ReadRequiredString("Select option: ");
            Console.WriteLine();

            switch (choice)
            {
                case "1":
                    ManageDonors();
                    break;
                case "2":
                    ManageRequests();
                    break;
                case "3":
                    UpsertStock();
                    break;
                case "4":
                    ScheduleAppointment();
                    break;
                case "5":
                    ShowReport();
                    break;
                case "6":
                    DeleteStock();
                    break;
                case "7":
                    return;
                default:
                    Console.WriteLine("Invalid option.");
                    break;
            }
        }
    }

    private void ManageDonors()
    {
        var group = ReadRequiredString("Filter by blood group (or * for all): ");
        var filter = group == "*" ? null : group;

        var donors = _adminService.SearchDonors(filter);
        if (donors.Count == 0)
        {
            Console.WriteLine("No donors found.");
            return;
        }

        Console.WriteLine("DonorId | UserId | Group | Age | Phone         | Address");
        foreach (var donor in donors)
        {
            Console.WriteLine($"{donor.DonorId,7} | {donor.UserId,6} | {donor.BloodGroup,5} | {donor.Age,3} | {donor.Phone,-13} | {donor.Address}");
        }

        var delete = ReadRequiredString("Delete a donor? (y/n): ").ToLowerInvariant();
        if (delete == "y")
        {
            var donorId = ReadInt("DonorId to delete: ", 1, int.MaxValue);
            var deleted = _adminService.DeleteDonor(donorId);
            Console.WriteLine(deleted ? "Donor deleted." : "Donor not found.");
        }
    }

    private void ManageRequests()
    {
        var statusInput = ReadRequiredString("Filter status (Pending/Approved/Rejected or *): ");
        var status = statusInput == "*" ? null : statusInput;
        var groupInput = ReadRequiredString("Filter blood group (or *): ");
        var group = groupInput == "*" ? null : groupInput;

        var requests = _adminService.SearchRequests(status, group);
        if (requests.Count == 0)
        {
            Console.WriteLine("No requests found.");
            return;
        }

        Console.WriteLine("RequestId | ReceiverId | Group | Qty | Status   | Date");
        foreach (var request in requests)
        {
            Console.WriteLine($"{request.RequestId,9} | {request.ReceiverId,10} | {request.BloodGroup,5} | {request.Quantity,3} | {request.Status,-8} | {request.RequestDate:yyyy-MM-dd}");
        }

        Console.WriteLine("1. Update status");
        Console.WriteLine("2. Delete request");
        Console.WriteLine("3. Back");
        var action = ReadRequiredString("Select action: ");

        switch (action)
        {
            case "1":
                var requestId = ReadInt("RequestId: ", 1, int.MaxValue);
                var newStatus = ReadRequiredString("New status (Pending/Approved/Rejected): ");
                var updated = _adminService.UpdateRequestStatus(requestId, newStatus);
                Console.WriteLine(updated ? "Request status updated." : "Could not update request.");
                break;

            case "2":
                var deleteId = ReadInt("RequestId to delete: ", 1, int.MaxValue);
                var deleted = _adminService.DeleteRequest(deleteId);
                Console.WriteLine(deleted ? "Request deleted." : "Request not found.");
                break;

            default:
                break;
        }
    }

    private void UpsertStock()
    {
        var bloodGroup = ReadRequiredString("Blood group: ");
        var quantity = ReadInt("Quantity: ", 0, 100000);
        var hospital = ReadRequiredString("Hospital/Blood bank name: ");

        var saved = _adminService.UpsertBloodStock(bloodGroup, quantity, hospital);
        Console.WriteLine(saved ? "Blood stock saved." : "Could not save blood stock.");
    }

    private void ScheduleAppointment()
    {
        var donorId = ReadInt("DonorId: ", 1, int.MaxValue);
        var date = ReadDate("Appointment date (yyyy-mm-dd): ");
        var status = ReadRequiredString("Status (Pending/Approved/Rejected/Completed): ");

        var scheduled = _adminService.ScheduleAppointment(donorId, date, status);
        Console.WriteLine(scheduled ? "Appointment scheduled." : "Could not schedule appointment.");
    }

    private void ShowReport()
    {
        var report = _adminService.GenerateReport();
        Console.WriteLine("--- Report ---");
        foreach (var item in report)
        {
            Console.WriteLine($"{item.Key}: {item.Value}");
        }
    }

    private void DeleteStock()
    {
        var stocks = _adminService.GetAllBloodStock();
        if (stocks.Count == 0)
        {
            Console.WriteLine("No stock entries found.");
            return;
        }

        Console.WriteLine("StockId | Group | Qty | Hospital");
        foreach (var stock in stocks)
        {
            Console.WriteLine($"{stock.StockId,7} | {stock.BloodGroup,5} | {stock.Quantity,3} | {stock.HospitalName}");
        }

        var stockId = ReadInt("StockId to delete: ", 1, int.MaxValue);
        var deleted = _adminService.DeleteBloodStock(stockId);
        Console.WriteLine(deleted ? "Stock entry deleted." : "Stock entry not found.");
    }

    private static string ReadRequiredString(string prompt, string? defaultValue = null)
    {
        while (true)
        {
            Console.Write(prompt);
            var input = Console.ReadLine()?.Trim();

            if (!string.IsNullOrWhiteSpace(input))
            {
                return input;
            }

            if (!string.IsNullOrWhiteSpace(defaultValue))
            {
                return defaultValue;
            }

            Console.WriteLine("Input is required.");
        }
    }

    private static int ReadInt(string prompt, int min, int max, int? defaultValue = null)
    {
        while (true)
        {
            Console.Write(prompt);
            var input = Console.ReadLine()?.Trim();

            if (string.IsNullOrWhiteSpace(input) && defaultValue.HasValue)
            {
                return defaultValue.Value;
            }

            if (int.TryParse(input, out var value) && value >= min && value <= max)
            {
                return value;
            }

            Console.WriteLine($"Enter a number between {min} and {max}.");
        }
    }

    private static DateTime ReadDate(string prompt)
    {
        while (true)
        {
            Console.Write(prompt);
            var input = Console.ReadLine()?.Trim();

            if (DateTime.TryParse(input, out var date))
            {
                return date;
            }

            Console.WriteLine("Enter a valid date.");
        }
    }

    private static DateTime? ReadOptionalDate(string prompt, DateTime? defaultValue = null)
    {
        while (true)
        {
            Console.Write(prompt);
            var input = Console.ReadLine()?.Trim();

            if (string.IsNullOrWhiteSpace(input))
            {
                return defaultValue;
            }

            if (DateTime.TryParse(input, out var date))
            {
                return date;
            }

            Console.WriteLine("Enter a valid date or leave blank.");
        }
    }
}
