package Frame;
import Entity.*;
import java.lang.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.*;

public class CanteenFrame extends JFrame implements MouseListener, ActionListener {
	private Font f1, f2;
	private Color c1, c2;
	private JPanel panel;
	private JLabel label1, label2, label3, label4, label5, label6, label7;
	private JTextField tf1;
	private JPasswordField pf1;
	private JButton bt1, bt2, bt3;
	private JRadioButton rb1, rb2;
	private ButtonGroup bg1;
	private JCheckBox cb1, cb2, cb3, cb4;
	private JComboBox jb;
	private JTextArea ta, ta2;
	private ImageIcon img;

	public CanteenFrame() {
		super("Canteen Ordering System");
		super.setBounds(200, 50, 1500, 1000);
		super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		panel = new JPanel();
		panel.setLayout(null);
		c2 = new Color(255, 255, 204);
		panel.setBackground(c2);

		f1 = new Font("Arial", Font.ITALIC, 50);
		f2 = new Font("Arial", Font.BOLD, 20);
		c1 = new Color(153, 0, 0);

		label1 = new JLabel("Welcome to AIUB Canteen");
		label1.setBounds(425, 0, 700, 50);
		label1.setFont(f1);
		label1.setForeground(c1);
		label1.addMouseListener(this);
		panel.add(label1);

		label3 = new JLabel("Customer Name");
		label3.setBounds(10, 70, 170, 30);
		label3.setFont(f2);
		panel.add(label3);

		tf1 = new JTextField();
		tf1.setBounds(190, 70, 150, 30);
		tf1.setFont(f2);
		panel.add(tf1);

		label4 = new JLabel("Contact No");
		label4.setBounds(10, 110, 150, 30);
		label4.setFont(f2);
		panel.add(label4);

		pf1 = new JPasswordField();
		pf1.setBounds(190, 110, 150, 30);
		pf1.setFont(f2);
		pf1.setEchoChar('*');
		pf1.addActionListener(this);
		panel.add(pf1);

		bt3 = new JButton("Show");
		bt3.setBounds(360, 110, 100, 30);
		bt3.setFont(f2);
		bt3.setBackground(Color.GREEN);
		bt3.addActionListener(this);
		panel.add(bt3);

		label2 = new JLabel("Order Type");
		label2.setBounds(10, 150, 150, 30);
		label2.setFont(f2);
		panel.add(label2);

		rb1 = new JRadioButton("Dine In");
		rb1.setBounds(190, 150, 100, 30);
		rb1.setFont(f2);
		panel.add(rb1);

		rb2 = new JRadioButton("Takeaway");
		rb2.setBounds(310, 150, 130, 30);
		rb2.setFont(f2);
		panel.add(rb2);

		bg1 = new ButtonGroup();
		bg1.add(rb1);
		bg1.add(rb2);

		label4 = new JLabel("Menu");
		label4.setBounds(10, 190, 120, 30);
		label4.setFont(f2);
		panel.add(label4);

		cb1 = new JCheckBox("Burger (Tk:120)");
		cb1.setBounds(190, 190, 200, 30);
		cb1.setFont(f2);
		panel.add(cb1);

		cb2 = new JCheckBox("Pizza (Tk:250)");
		cb2.setBounds(190, 240, 200, 30);
		cb2.setFont(f2);
		panel.add(cb2);

		cb3 = new JCheckBox("Sandwich (Tk:100)");
		cb3.setBounds(190, 290, 200, 30);
		cb3.setFont(f2);
		panel.add(cb3);

		cb4 = new JCheckBox("Fries (Tk:80)");
		cb4.setBounds(190, 340, 200, 30);
		cb4.setFont(f2);
		panel.add(cb4);

		label5 = new JLabel("Payment Method");
		label5.setBounds(10, 390, 180, 30);
		label5.setFont(f2);
		panel.add(label5);

		String items[] = new String[]{"", "CASH", "BKASH", "NAGAD", "CARD"};
		jb = new JComboBox(items);
		jb.setBounds(200, 390, 180, 30);
		jb.setFont(f2);
		panel.add(jb);

		label6 = new JLabel("Special Request");
		label6.setBounds(10, 560, 200, 30);
		label6.setFont(f2);
		label6.setBackground(c2);
		label6.setOpaque(true);
		label6.addMouseListener(this);
		panel.add(label6);

		ta = new JTextArea();
		ta.setBounds(10, 590, 320, 200);
		ta.setFont(f2);
		panel.add(ta);

		img = new ImageIcon("Picture/canteen.png"); 
		label7 = new JLabel(img);
		label7.setBounds(440, 140, 300, 300);
		panel.add(label7);

		bt1 = new JButton("Place Order");
		bt1.setBounds(10, 810, 150, 30);
		bt1.setFont(f2);
		bt1.setBackground(Color.GREEN);
		bt1.addMouseListener(this);
		bt1.addActionListener(this);
		panel.add(bt1);

		bt2 = new JButton("Exit");
		bt2.setBounds(870, 810, 150, 30);
		bt2.setFont(f2);
		bt2.setBackground(Color.GREEN);
		bt2.addActionListener(this);
		panel.add(bt2);

		ta2 = new JTextArea();
		JScrollPane scrollPane = new JScrollPane(ta2);
		scrollPane.setBounds(870, 170, 460, 510);
		ta2.setFont(f2);
		panel.add(scrollPane);

		super.add(panel);
	}

	public void mouseClicked(MouseEvent me) {
		if (me.getSource() == label1) {
			label1.setText("AIUB Canteen System");
		}
	}

	public void mousePressed(MouseEvent me) {
		if (me.getSource() == label6) {
			label6.setText("Comments");
		}
	}

	public void mouseReleased(MouseEvent me) {
		if (me.getSource() == label6) {
			label6.setText("Special Request");
		}
	}

	public void mouseEntered(MouseEvent me) {
		if (me.getSource() == bt1) {
			bt1.setBackground(Color.BLUE);
			bt1.setForeground(Color.WHITE);
		}
	}

	public void mouseExited(MouseEvent me) {
		if (me.getSource() == bt1) {
			bt1.setBackground(Color.GREEN);
			bt1.setForeground(Color.BLACK);
		}
	}

	public void actionPerformed(ActionEvent ae) {
		if (ae.getSource() == bt2) {
			System.exit(0);
		}
		if (ae.getSource() == bt3) {
			pf1.setEchoChar((char) 0);
		}
		if (ae.getSource() == bt1) {
			String f1, f2, f3, f4, f5, f6;
			int totalAmount = 0;

			f1 = tf1.getText();
			f2 = pf1.getText();

			if (rb1.isSelected()) { f3 = rb1.getText(); }
			else if (rb2.isSelected()) { f3 = rb2.getText(); }
			else { f3 = ""; }

			StringBuilder foodBuilder = new StringBuilder();
			if (cb1.isSelected()) { foodBuilder.append("\n Burger                                -120TK "); totalAmount += 120; }
			if (cb2.isSelected()) { foodBuilder.append("\n Pizza                                 -250Tk "); totalAmount += 250; }
			if (cb3.isSelected()) { foodBuilder.append("\n Sandwich                          -100Tk "); totalAmount += 100; }
			if (cb4.isSelected()) { foodBuilder.append("\n Fries                                 -80Tk "); totalAmount += 80; }
			f4 = foodBuilder.toString();
            f5 =   jb.getSelectedItem().toString();      
            f6 =   ta.getText();                  


			if (f1.isEmpty() || f2.isEmpty() || f3.isEmpty() || f4.isEmpty() || f5.isEmpty() || f6.isEmpty()) {
				JOptionPane.showMessageDialog(this, "Please fill up all information!");
			} else {
				Food order = new Food(f1, f2, f3, f4, f5, f6, totalAmount);
				order.insertInfo();
				JOptionPane.showMessageDialog(this, "Order placed successfully! Total: Tk" + totalAmount);
				check();
			}
		}
	}

	private void check() {
		try {
			File file = new File("./Data/orderdata.txt");
			if (file.exists()) {
				FileReader fr = new FileReader(file);
				BufferedReader br = new BufferedReader(fr);
				String line;
				while ((line = br.readLine()) != null) {
					ta2.append(line + "\n");
				}
				br.close();
			}
		} catch (IOException ioe) {
			ioe.printStackTrace();
			JOptionPane.showMessageDialog(this, "Error!");
		}
	}
}



