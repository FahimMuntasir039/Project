import java.lang.*;
import Frame.*;

public class Start {
	public static void main(String[] args) {
		CanteenFrame obj = new CanteenFrame();
		obj.setVisible(true);
	}
}
