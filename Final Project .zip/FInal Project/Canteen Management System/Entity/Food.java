package Entity;
import java.lang.*;
import javax.swing.*;
import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Food {
	private String f1, f2, f3, f4, f5, f6;
	private int totalAmount;

	private File file;
	private FileWriter fwriter;

	public Food() { }

	public Food(String f1, String f2, String f3, String f4, String f5, String f6, int totalAmount) {
		this.f1 = f1;
		this.f2 = f2;
		this.f3 = f3;
		this.f4 = f4;
		this.f5 = f5;
		this.f6 = f6;
		this.totalAmount = totalAmount;
	}

	public void insertInfo() {
		try {
			file = new File("./Data/orderdata.txt");
			if (!file.exists()) {
				file.getParentFile().mkdirs();
				file.createNewFile();
			}

			LocalDateTime myDateObj = LocalDateTime.now();
			DateTimeFormatter myFormatObj = DateTimeFormatter.ofPattern("HH:mm a, dd/MM/yyyy");
			String timeAndDate = myDateObj.format(myFormatObj);

			fwriter = new FileWriter(file, true);
			fwriter.write("Date and Time: " + timeAndDate + "\n");
			fwriter.write("--------------------------------------------------------\n");
			fwriter.write("Customer Name: " + f1 + "\n");
			fwriter.write("Contact No: " + f2 + "\n");
			fwriter.write("Order Type: " + f3 + "\n");
			fwriter.write("Selected Foods: " + f4 + "\n");
			fwriter.write("--------------------------------------------------------\n");
			fwriter.write("Total Bill:                   Tk" + totalAmount + "\n");
			fwriter.write("Payment Method: " + f5+  "\n");
			fwriter.write("Special Request: " + f6 + "\n");
			
			fwriter.write("========================================================\n");
		
			fwriter.flush();
			fwriter.close();
		} 
		
		catch (IOException ioe) 
		{
			ioe.printStackTrace();
			JOptionPane.showMessageDialog(null, "Error writing to file!");
		}
	}
}

